"""Live UK Weather Operations dashboard.

Run:  streamlit run app.py
Historical data comes from data/processed/*.parquet (built by run_pipeline.py, or from the button below).
Live conditions come from the Open-Meteo Forecast API and refresh automatically.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

import config
from src import analysis, api_client, processing

st.set_page_config(page_title="UK Weather Operations", page_icon="🌦️", layout="wide")

INK, ISOBAR, RAIN, HEAT, CLOUD, PAPER = "#1B2A35", "#2F6690", "#3A7D7C", "#C8553D", "#8D99AE", "#F3F6F8"
CITY_COLORS = dict(zip(config.CITIES, analysis.CITY_COLORS))
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible:wght@400;700&display=swap');
html, body, [class*="css"], .stMarkdown, .stMetric, button, input { font-family: 'Atkinson Hyperlegible', system-ui, sans-serif; }
h1 { font-size: 2.1rem !important; letter-spacing: -0.01em; margin-bottom: 0 !important; }
[data-testid="stMetricValue"] { font-size: 1.7rem; }
[data-testid="stMetric"] { border-left: 3px solid #2F6690; padding-left: .7rem; }
.live-note { color: #556B7D; font-size: .9rem; }
</style>""", unsafe_allow_html=True)


def style_fig(fig, height=380):
    fig.update_layout(height=height, margin=dict(l=10, r=10, t=40, b=10), paper_bgcolor="rgba(0,0,0,0)",
                      plot_bgcolor="rgba(0,0,0,0)", font=dict(family="Atkinson Hyperlegible, sans-serif", color=INK),
                      legend=dict(orientation="h", y=-0.2), hoverlabel=dict(font_family="Atkinson Hyperlegible"))
    fig.update_xaxes(gridcolor="#DCE3EA"); fig.update_yaxes(gridcolor="#DCE3EA")
    return fig


# ================================================================ data loading
@st.cache_data(show_spinner=False)
def load_history():
    hp, dp = config.PROCESSED_DIR / "hourly.parquet", config.PROCESSED_DIR / "daily.parquet"
    if not (hp.exists() and dp.exists()):
        return None
    h, d = pd.read_parquet(hp), pd.read_parquet(dp)
    for df in (h, d):
        df["season"] = pd.Categorical(df["season"].astype(str), categories=config.SEASON_ORDER, ordered=True)
    h["time_local"] = pd.to_datetime(h["time_utc"], utc=True).dt.tz_convert(config.LOCAL_TZ)
    d["date"] = pd.to_datetime(d["date"])
    meta_path = config.PROCESSED_DIR / "meta.json"
    meta = json.loads(meta_path.read_text()) if meta_path.exists() else {}
    return h, d, meta


def build_history():
    payloads, failures = api_client.fetch_historical_all(list(config.CITIES), config.DEFAULT_START, config.DEFAULT_END)
    if not payloads:
        raise RuntimeError(f"No cities downloaded: {failures}")
    raw = processing.payloads_to_frame(payloads)
    clean, log = processing.clean(raw)
    h = processing.add_features(clean)
    config.PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    h.to_parquet(config.PROCESSED_DIR / "hourly.parquet", index=False)
    processing.daily_aggregate(h).to_parquet(config.PROCESSED_DIR / "daily.parquet", index=False)
    (config.PROCESSED_DIR / "meta.json").write_text(json.dumps(
        {"start": str(config.DEFAULT_START), "end": str(config.DEFAULT_END), "cities": sorted(payloads),
         "failures": failures, "units": processing.units_from_payload(next(iter(payloads.values()))),
         "cleaning_log": log}, indent=2, default=str))


@st.cache_data(ttl=240, show_spinner=False)
def load_live(cities: tuple[str, ...]):
    payloads = api_client.fetch_live(list(cities))
    return (api_client.live_current_to_df(payloads), api_client.live_hourly_to_df(payloads),
            datetime.now(timezone.utc))


def typical_conditions(h: pd.DataFrame, cur: pd.DataFrame) -> pd.DataFrame:
    """Historical mean for each city at the same calendar month and local hour as its live reading."""
    keys = cur[["city"]].assign(month=cur["time_local"].dt.month, hour=cur["time_local"].dt.hour)
    base = (h.groupby(["city", "month", "hour"])[["temp_c", "rh_pct", "wind_kmh", "pressure_hpa", "cloud_pct", "gust_kmh"]]
            .mean().add_prefix("typ_").reset_index())
    return keys.merge(base, on=["city", "month", "hour"], how="left").drop(columns=["month", "hour"])


# ================================================================ header + history gate
st.title("UK weather operations")
hist = load_history()
if hist is None:
    st.info("No historical data on disk yet. Download 12 months of hourly history for all cities from Open-Meteo "
            "(about 12 requests, usually 1–3 minutes), or run `python run_pipeline.py` for the full report.")
    if st.button("Download history", type="primary"):
        with st.spinner("Downloading and processing Open-Meteo history…"):
            try:
                build_history()
            except Exception as exc:  # noqa: BLE001 - surfaced to the user
                st.error(f"History download failed: {exc}")
                st.stop()
        load_history.clear(); st.rerun()
    st.stop()

H, D, META = hist
D_FULL = D[D["is_full_day"]]
cities_available = sorted(H["city"].unique(), key=list(config.CITIES).index)

# ================================================================ sidebar
with st.sidebar:
    st.header("Controls")
    focus = st.selectbox("Focus city", cities_available, index=cities_available.index("London") if "London" in cities_available else 0)
    selected = st.multiselect("Cities to compare", cities_available, default=cities_available)
    dmin, dmax = D["date"].min().date(), D["date"].max().date()
    date_range = st.date_input("Historical period", (dmin, dmax), min_value=dmin, max_value=dmax)
    refresh_min = st.selectbox("Live refresh every", [5, 10, 15, 30], index=1, format_func=lambda m: f"{m} minutes")
    if st.button("Refresh live data now"):
        load_live.clear()
    st.caption(f"History: {META.get('start', dmin)} to {META.get('end', dmax)} (Open-Meteo archive, UTC → UK time). "
               "Wind in km/h at 10 m; pressure at mean sea level.")
    if META.get("failures"):
        st.warning("Not downloaded: " + ", ".join(META["failures"]))

if not selected:
    st.warning("Choose at least one city to compare."); st.stop()
start_d, end_d = (date_range if isinstance(date_range, tuple) and len(date_range) == 2 else (dmin, dmax))
hmask = H["city"].isin(selected) & (H["time_local"].dt.date >= start_d) & (H["time_local"].dt.date <= end_d)
HF = H[hmask]
DF = D_FULL[D_FULL["city"].isin(selected) & (D_FULL["date"].dt.date >= start_d) & (D_FULL["date"].dt.date <= end_d)]
if HF.empty or DF.empty:
    st.warning("No data for that selection. Widen the date range or add cities."); st.stop()


# ================================================================ live panel (auto-refresh fragment)
def live_panel():
    try:
        cur, live_h, fetched = load_live(tuple(cities_available))
    except Exception as exc:  # noqa: BLE001
        st.error(f"Live conditions unavailable ({exc}). Historical analysis below still works; live data retries on the next refresh.")
        return
    cur = cur.merge(typical_conditions(H, cur), on="city", how="left")
    cur["temp_vs_typical"] = cur["temp_c"] - cur["typ_temp_c"]
    row = cur.set_index("city").loc[focus]

    st.subheader(f"Now in {focus}: {row['condition'].lower()}")
    st.markdown(f"<span class='live-note'>Model time {row['time_local']:%H:%M %a %d %b} · fetched "
                f"{pd.Timestamp(fetched).tz_convert(config.LOCAL_TZ):%H:%M:%S} · refreshes every {refresh_min} min · "
                f"“vs typical” = this city's mean for the same month and hour in the history</span>", unsafe_allow_html=True)
    c = st.columns(7)
    c[0].metric("Temperature", f"{row['temp_c']:.1f} °C", f"{row['temp_vs_typical']:+.1f} °C vs typical", delta_color="off")
    c[1].metric("Feels like", f"{row['feels_like_c']:.1f} °C")
    c[2].metric("Humidity", f"{row['rh_pct']:.0f}%", f"{row['rh_pct'] - row['typ_rh_pct']:+.0f} pts vs typical", delta_color="off")
    c[3].metric("Wind", f"{row['wind_kmh']:.0f} km/h", f"gusts {row['gust_kmh']:.0f} km/h", delta_color="off")
    c[4].metric("Pressure", f"{row['pressure_hpa']:.0f} hPa", f"{row['pressure_hpa'] - row['typ_pressure_hpa']:+.0f} vs typical", delta_color="off")
    c[5].metric("Cloud cover", f"{row['cloud_pct']:.0f}%")
    c[6].metric("Precipitation", f"{row['precip_mm']:.1f} mm", "preceding hour", delta_color="off")

    alerts = cur[(cur["gust_kmh"] >= config.GALE_GUST_KMH) | (cur["precip_mm"] >= config.HEAVY_RAIN_HOUR_MM) | (cur["temp_c"] < config.FROST_C)]
    for _, a in alerts.iterrows():
        reasons = [r for r, cond in [(f"gusts {a['gust_kmh']:.0f} km/h", a["gust_kmh"] >= config.GALE_GUST_KMH),
                                     (f"rain {a['precip_mm']:.1f} mm/h", a["precip_mm"] >= config.HEAVY_RAIN_HOUR_MM),
                                     (f"temperature {a['temp_c']:.1f} °C", a["temp_c"] < config.FROST_C)] if cond]
        st.warning(f"{a['city']}: " + ", ".join(reasons))

    left, right = st.columns([1.05, 1])
    with left:
        fig = px.scatter_map(cur, lat="lat", lon="lon", color="temp_c", size=np.clip(cur["wind_kmh"], 5, None),
                             hover_name="city", text="city", color_continuous_scale="RdYlBu_r",
                             hover_data={"temp_c": ":.1f", "condition": True, "wind_kmh": ":.0f", "precip_mm": ":.1f", "lat": False, "lon": False},
                             zoom=4.4, center={"lat": 54.4, "lon": -3.2}, map_style="carto-positron",
                             labels={"temp_c": "°C"})
        fig.update_traces(textposition="top right")
        st.plotly_chart(style_fig(fig, 520).update_layout(title="Live temperature (colour) and wind (size)"), width="stretch")
    with right:
        tbl = cur[["city", "condition", "temp_c", "temp_vs_typical", "feels_like_c", "rh_pct", "wind_kmh", "gust_kmh",
                   "precip_mm", "pressure_hpa", "cloud_pct"]].sort_values("temp_c", ascending=False)
        st.dataframe(tbl, hide_index=True, width="stretch", height=470, column_config={
            "city": "City", "condition": "Condition", "temp_c": st.column_config.NumberColumn("Temp °C", format="%.1f"),
            "temp_vs_typical": st.column_config.NumberColumn("vs typical", format="%+.1f"),
            "feels_like_c": st.column_config.NumberColumn("Feels °C", format="%.1f"),
            "rh_pct": st.column_config.NumberColumn("RH %", format="%.0f"),
            "wind_kmh": st.column_config.NumberColumn("Wind", format="%.0f"),
            "gust_kmh": st.column_config.NumberColumn("Gust", format="%.0f"),
            "precip_mm": st.column_config.NumberColumn("Rain mm", format="%.1f"),
            "pressure_hpa": st.column_config.NumberColumn("hPa", format="%.0f"),
            "cloud_pct": st.column_config.NumberColumn("Cloud %", format="%.0f")})

    lf = live_h[live_h["city"] == focus]
    now = row["time_local"]
    fig = go.Figure()
    fig.add_bar(x=lf["time_local"], y=lf["precip_mm"], name="Precipitation (mm)", marker_color=RAIN, yaxis="y2", opacity=.6)
    fig.add_scatter(x=lf["time_local"], y=lf["temp_c"], name="Temperature (°C)", line=dict(color=HEAT, width=2.5))
    fig.add_scatter(x=lf["time_local"], y=lf["gust_kmh"], name="Gusts (km/h)", line=dict(color=CLOUD, dash="dot"), yaxis="y3")
    fig.add_vline(x=now, line_color=INK, line_dash="dash")
    fig.add_annotation(x=now, y=1, yref="paper", text="now", showarrow=False, yanchor="bottom")
    fig.update_layout(title=f"{focus}: yesterday, today and tomorrow (Open-Meteo forecast model)",
                      yaxis=dict(title="°C"), yaxis2=dict(title="mm", overlaying="y", side="right", showgrid=False),
                      yaxis3=dict(overlaying="y", side="right", anchor="free", autoshift=True, showgrid=False, title="km/h"))
    st.plotly_chart(style_fig(fig, 360), width="stretch")


st.fragment(run_every=refresh_min * 60)(live_panel)()

# ================================================================ historical KPIs
st.divider()
st.subheader(f"History: {start_d:%d %b %Y} to {end_d:%d %b %Y}, {len(selected)} cities")
k = analysis.compute_kpis(HF, DF).set_index("kpi")
rows = [st.columns(6), st.columns(6)]
for i, (name, r) in enumerate(k.iterrows()):
    label = name.replace(" (mean per city)", "").replace(" (≥1 mm, mean per city)", " (≥1 mm)")
    rows[i // 6][i % 6].metric(label, f"{r['value']:,.1f} {r['unit']}" if "location" not in name else r["detail"].split(" (")[0],
                               help=r["detail"])

tab_tr, tab_hw, tab_cmp, tab_pat, tab_ext, tab_data = st.tabs(
    ["Temperature & rainfall", "Humidity & wind", "City comparison", "Seasonal & daily patterns", "Extremes", "Data & quality"])

with tab_tr:
    smooth = st.radio("Temperature smoothing", ["Daily", "7-day rolling", "30-day rolling"], horizontal=True, index=1)
    col = {"Daily": "temp_mean", "7-day rolling": "temp_mean_roll7d", "30-day rolling": "temp_mean_roll30d"}[smooth]
    fig = px.line(DF, x="date", y=col, color="city", color_discrete_map=CITY_COLORS, labels={col: "°C", "date": ""},
                  title=f"Daily mean temperature ({smooth.lower()})")
    st.plotly_chart(style_fig(fig, 420), width="stretch")
    c1, c2 = st.columns(2)
    wk = DF.set_index("date").groupby("city")["precip_sum"].resample("W-MON").sum().reset_index()
    c1.plotly_chart(style_fig(px.bar(wk, x="date", y="precip_sum", color="city", color_discrete_map=CITY_COLORS,
                                     labels={"precip_sum": "mm", "date": "Week"}, title="Weekly rainfall (stacked by city)")), width="stretch")
    mr = DF.groupby(["year_month", "city"])["precip_sum"].sum().reset_index()
    c2.plotly_chart(style_fig(px.line(mr, x="year_month", y="precip_sum", color="city", markers=True, color_discrete_map=CITY_COLORS,
                                      labels={"precip_sum": "mm", "year_month": ""}, title="Monthly rainfall by city")), width="stretch")
    fh = HF[HF["city"] == focus]
    if not fh.empty:
        tail = fh[fh["time_local"] >= fh["time_local"].max() - pd.Timedelta(days=21)]
        fig = go.Figure()
        fig.add_scatter(x=tail["time_local"], y=tail["temp_c"], name="Hourly", line=dict(color="#B8C2CC", width=1))
        fig.add_scatter(x=tail["time_local"], y=tail["temp_c_roll24h"], name="24-hour mean", line=dict(color=ISOBAR))
        fig.add_scatter(x=tail["time_local"], y=tail["temp_c_roll168h"], name="7-day mean", line=dict(color=HEAT, width=3))
        st.plotly_chart(style_fig(fig.update_layout(title=f"{focus}: hourly temperature with rolling means (last 21 days of selection)",
                                                   yaxis_title="°C")), width="stretch")

with tab_hw:
    c1, c2 = st.columns(2)
    smp = HF.sample(min(len(HF), 30000), random_state=1)
    c1.plotly_chart(style_fig(px.density_heatmap(smp, x="temp_c", y="rh_pct", nbinsx=40, nbinsy=40, color_continuous_scale="Blues",
                                                 labels={"temp_c": "°C", "rh_pct": "RH %"}, title="Temperature vs humidity (hour density)")), width="stretch")
    rp = HF.groupby(["rh_band", "city"], observed=True)["is_rain_hour"].mean().mul(100).reset_index()
    c2.plotly_chart(style_fig(px.line(rp, x="rh_band", y="is_rain_hour", color="city", markers=True, color_discrete_map=CITY_COLORS,
                                      labels={"is_rain_hour": "% hours with rain", "rh_band": "RH %"}, title="Chance of rain by humidity")), width="stretch")
    c3, c4 = st.columns(2)
    fw = HF[HF["city"] == focus].dropna(subset=["wind_dir_8", "beaufort"])
    if not fw.empty:
        rose = fw.assign(force=pd.cut(fw["wind_kmh"], [-1, 11, 19, 28, 38, 49, 400], labels=["0–11", "12–19", "20–28", "29–38", "39–49", "50+"]))
        rose = rose.groupby(["wind_dir_8", "force"], observed=True).size().div(len(fw)).mul(100).reset_index(name="pct")
        fig = px.bar_polar(rose, r="pct", theta="wind_dir_8", color="force", color_discrete_sequence=px.colors.sequential.Purples[2:],
                           category_orders={"wind_dir_8": ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]}, title=f"{focus}: wind rose (% of hours, km/h)")
        c3.plotly_chart(style_fig(fig), width="stretch")
    wind7 = DF.assign(wind_7d=DF.groupby("city")["wind_mean"].transform(lambda s: s.rolling(7, min_periods=5).mean()))
    c4.plotly_chart(style_fig(px.line(wind7, x="date", y="wind_7d", color="city", color_discrete_map=CITY_COLORS,
                                      labels={"wind_7d": "km/h", "date": ""},
                                      title="Mean wind speed, 7-day rolling")), width="stretch")
    pw = HF.groupby("pressure_band", observed=True).agg(wind=("wind_kmh", "mean"), rain=("is_rain_hour", "mean")).reset_index()
    fig = go.Figure([go.Bar(x=pw["pressure_band"].astype(str), y=pw["wind"], name="Mean wind km/h", marker_color=ISOBAR),
                     go.Scatter(x=pw["pressure_band"].astype(str), y=pw["rain"] * 100, name="% hours with rain", yaxis="y2", line=dict(color=RAIN, width=3))])
    fig.update_layout(title="Wind and rain by pressure band", xaxis_title="hPa", yaxis2=dict(overlaying="y", side="right", showgrid=False))
    st.plotly_chart(style_fig(fig), width="stretch")

with tab_cmp:
    cmp = analysis.city_comparison(HF, DF) if len(selected) > 1 else None
    if cmp is None:
        st.info("Select two or more cities to compare.")
    else:
        st.dataframe(cmp["table"], width="stretch")
        metric = st.selectbox("Compare by", [c for c in cmp["table"].columns if c != "nation"], index=0)
        srt = cmp["table"][metric].sort_values()
        bar_df = srt.rename_axis("city").reset_index()
        st.plotly_chart(style_fig(px.bar(bar_df, x=metric, y="city", orientation="h", color="city",
                                         color_discrete_map=CITY_COLORS, title=metric).update_layout(showlegend=False)), width="stretch")
        var = st.selectbox("City × month heatmap of", ["temp_c", "precip_mm", "wind_kmh", "rh_pct", "cloud_pct", "pressure_hpa"])
        agg = "sum" if var == "precip_mm" else "mean"
        hm = HF.pivot_table(index="city", columns="year_month", values=var, aggfunc=agg)
        if var == "precip_mm":
            hm = hm.where(HF.pivot_table(index="city", columns="year_month", values=var, aggfunc="count") > 0)
        st.plotly_chart(style_fig(px.imshow(hm, aspect="auto", text_auto=".0f" if var == "precip_mm" else ".1f",
                                            color_continuous_scale="Blues" if var in ("precip_mm", "rh_pct", "cloud_pct") else "RdYlBu_r",
                                            title=f"{var} ({agg}) by city and month"), 460), width="stretch")

with tab_pat:
    c1, c2 = st.columns(2)
    fh = HF[HF["city"] == focus]
    hm = fh.pivot_table(index="hour", columns="month_name", values="temp_c", aggfunc="mean")
    hm = hm[[m for m in ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"] if m in hm]]
    c1.plotly_chart(style_fig(px.imshow(hm, aspect="auto", origin="lower", color_continuous_scale="RdYlBu_r",
                                        labels={"y": "Local hour", "x": "", "color": "°C"}, title=f"{focus}: temperature by hour and month"), 460), width="stretch")
    c2.plotly_chart(style_fig(px.box(DF, x="season", y="temp_mean", color="season", points=False,
                                     category_orders={"season": config.SEASON_ORDER},
                                     color_discrete_map=analysis.SEASON_COLORS, labels={"temp_mean": "Daily mean °C", "season": ""},
                                     title="Daily mean temperature by season").update_layout(showlegend=False), 460), width="stretch")
    sp = DF.groupby(["season", "city"], observed=True).agg(rain=("precip_sum", "sum"), wet=("wet_day", "mean")).reset_index()
    st.plotly_chart(style_fig(px.bar(sp, x="city", y="rain", color="season", barmode="group",
                                     category_orders={"season": config.SEASON_ORDER}, color_discrete_map=analysis.SEASON_COLORS,
                                     labels={"rain": "mm", "city": ""}, title="Seasonal rainfall by city")), width="stretch")

with tab_ext:
    ext = analysis.extremes(HF, DF)
    st.dataframe(ext["counts"], width="stretch")
    c1, c2 = st.columns(2)
    c1.markdown("**Strongest gusts**"); c1.dataframe(ext["tables"]["strongest_gusts"], hide_index=True, width="stretch")
    c2.markdown("**Heaviest hourly rain**"); c2.dataframe(ext["tables"]["wettest_hours"], hide_index=True, width="stretch")
    c1.markdown("**Hottest hours**"); c1.dataframe(ext["tables"]["hottest_hours"], hide_index=True, width="stretch")
    c2.markdown("**Coldest hours**"); c2.dataframe(ext["tables"]["coldest_hours"], hide_index=True, width="stretch")
    st.markdown("**City alert thresholds from this selection** (1st/99th percentiles)")
    st.dataframe(ext["thresholds"], width="stretch")

with tab_data:
    st.markdown(f"Historical window {META.get('start')} to {META.get('end')} · {len(H):,} hourly rows · "
                f"{H['was_imputed'].mean() * 100:.2f}% of rows contain a short-gap interpolated value.")
    if META.get("cleaning_log"):
        st.json(META["cleaning_log"], expanded=False)
    st.dataframe(HF.isna().mean().mul(100).round(3).rename("% missing").to_frame().query("`% missing` > 0"), width="stretch")
    st.download_button("Download filtered hourly data (CSV)", HF.drop(columns=["time_local"]).to_csv(index=False).encode(),
                       file_name=f"uk_weather_hourly_{start_d}_{end_d}.csv", mime="text/csv")
    st.caption("Source: Open-Meteo.com (CC BY 4.0). Historical values are ERA5-based reanalysis for the model grid cell nearest each city, not station observations.")
