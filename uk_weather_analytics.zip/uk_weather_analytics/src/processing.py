"""JSON -> Pandas, data-quality assessment, cleaning and feature engineering."""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd

import config

log = logging.getLogger(__name__)


# ================================================================ JSON -> Pandas
def payload_to_frame(payload: dict) -> pd.DataFrame:
    """Convert one Archive API JSON payload into a tidy hourly DataFrame."""
    meta = payload["_meta"]
    hourly = payload.get("hourly")
    if not hourly or "time" not in hourly:
        raise ValueError(f"No hourly block in payload for {meta['city']}")
    df = pd.DataFrame(hourly).rename(columns=config.RENAME)
    df["time_utc"] = pd.to_datetime(df.pop("time"), utc=True)
    city = meta["city"]
    df.insert(0, "city", city)
    df["nation"] = config.CITIES[city]["nation"]
    df["lat"] = config.CITIES[city]["lat"]
    df["lon"] = config.CITIES[city]["lon"]
    # Coordinates/elevation of the model grid cell actually used by Open-Meteo
    df["grid_lat"] = payload.get("latitude")
    df["grid_lon"] = payload.get("longitude")
    df["grid_elevation_m"] = payload.get("elevation")
    return df


def payloads_to_frame(payloads: dict) -> pd.DataFrame:
    frames = [payload_to_frame(p) for p in payloads.values()]
    df = pd.concat(frames, ignore_index=True)
    log.info("Raw frame: %d rows x %d cols for %d cities", *df.shape, df["city"].nunique())
    return df


def units_from_payload(payload: dict) -> dict:
    """Units exactly as reported by the API, renamed to project column names."""
    return {config.RENAME.get(k, k): v for k, v in payload.get("hourly_units", {}).items()}


# ================================================================ Data quality
def quality_assessment(df: pd.DataFrame, start, end) -> dict[str, pd.DataFrame]:
    """Completeness, missingness, duplicates, out-of-range and timestamp gaps per city."""
    expected_hours = int((pd.Timestamp(end) - pd.Timestamp(start)).days + 1) * 24
    value_cols = [c for c in config.VALID_RANGES if c in df.columns] + ["weather_code", "is_day"]

    rows = []
    for city, g in df.groupby("city"):
        full_idx = pd.date_range(g["time_utc"].min(), g["time_utc"].max(), freq="h")
        rows.append({
            "city": city,
            "rows": len(g),
            "expected_rows": expected_hours,
            "completeness_pct": round(100 * g["time_utc"].nunique() / expected_hours, 2),
            "duplicate_timestamps": int(g["time_utc"].duplicated().sum()),
            "missing_timestamps": int(len(full_idx.difference(g["time_utc"]))),
            "cells_missing": int(g[value_cols].isna().sum().sum()),
            "first_utc": g["time_utc"].min(), "last_utc": g["time_utc"].max(),
            "grid_elevation_m": g["grid_elevation_m"].iloc[0],
        })
    summary = pd.DataFrame(rows).set_index("city")

    missing = (df[value_cols].isna().groupby(df["city"]).mean() * 100).round(3)

    oor = {}
    for col, (lo, hi) in config.VALID_RANGES.items():
        if col in df.columns:
            bad = (df[col] < lo) | (df[col] > hi)
            oor[col] = bad.groupby(df["city"]).sum()
    out_of_range = pd.DataFrame(oor).fillna(0).astype(int)

    consistency = pd.DataFrame({
        "rain_gt_precip": ((df["rain_mm"] - df["precip_mm"]) > 0.05).groupby(df["city"]).sum(),
        "dewpoint_gt_temp": ((df["dew_point_c"] - df["temp_c"]) > 0.5).groupby(df["city"]).sum(),
        "gust_lt_wind": ((df["wind_kmh"] - df["gust_kmh"]) > 0.5).groupby(df["city"]).sum(),
    }).astype(int)

    dtypes = df.dtypes.astype(str).rename("dtype").to_frame()
    return {"summary": summary, "missing_pct": missing, "out_of_range": out_of_range,
            "consistency": consistency, "dtypes": dtypes}


# ================================================================ Cleaning
def clean(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Deduplicate, enforce full hourly grid, null invalid values, fill short gaps only."""
    logbook = {"rows_in": len(df)}
    df = df.sort_values(["city", "time_utc"])
    dupes = df.duplicated(["city", "time_utc"]).sum()
    df = df.drop_duplicates(["city", "time_utc"], keep="first")
    logbook["duplicates_removed"] = int(dupes)

    invalid = {}
    for col, (lo, hi) in config.VALID_RANGES.items():
        if col in df.columns:
            mask = (df[col] < lo) | (df[col] > hi)
            invalid[col] = int(mask.sum())
            df.loc[mask, col] = np.nan
    logbook["invalid_values_nulled"] = invalid

    static_cols = ["nation", "lat", "lon", "grid_lat", "grid_lon", "grid_elevation_m"]
    out, inserted, imputed = [], 0, {}
    for city, g in df.groupby("city", sort=False):
        g = g.set_index("time_utc")
        full = pd.date_range(g.index.min(), g.index.max(), freq="h", name="time_utc")
        inserted += len(full) - len(g)
        g = g.reindex(full)
        g["city"] = city
        g[static_cols] = g[static_cols].ffill().bfill()
        before = g.isna()
        g["was_imputed"] = False
        for col in [c for c in config.CONTINUOUS_VARS if c in g]:
            g[col] = g[col].interpolate(method="time", limit=config.MAX_INTERPOLATION_HOURS,
                                        limit_area="inside")
        for col in ["weather_code", "is_day", "wind_dir_deg"]:
            if col in g:
                g[col] = g[col].ffill(limit=1)
        # Accumulations are NOT interpolated: an unknown rain hour stays unknown.
        filled = before & g.notna()
        for col in filled.columns:
            n = int(filled[col].sum())
            if n:
                imputed[col] = imputed.get(col, 0) + n
        g["was_imputed"] = filled.any(axis=1)
        out.append(g.reset_index())
    df = pd.concat(out, ignore_index=True)

    logbook["timestamps_inserted"] = int(inserted)
    logbook["values_imputed"] = imputed
    logbook["remaining_missing"] = {k: int(v) for k, v in df.isna().sum().items() if v}
    df["weather_code"] = df["weather_code"].astype("Int64")
    df["is_day"] = df["is_day"].astype("Int64")
    logbook["rows_out"] = len(df)
    return df, logbook


# ================================================================ Feature engineering
def _beaufort(kmh: pd.Series) -> tuple[pd.Series, pd.Series]:
    edges = [-0.01] + [b[0] for b in config.BEAUFORT]
    edges[-1] = np.inf
    numbers = pd.cut(kmh, bins=edges, labels=[b[1] for b in config.BEAUFORT], right=True)
    labels = pd.cut(kmh, bins=edges, labels=[f"F{b[1]} {b[2]}" for b in config.BEAUFORT], right=True)
    return numbers.astype("float"), labels


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    t = df["time_utc"].dt.tz_convert(config.LOCAL_TZ)
    df["time_local"] = t
    df["date"] = t.dt.date
    df["year"] = t.dt.year
    df["month"] = t.dt.month
    df["month_name"] = t.dt.strftime("%b")
    df["year_month"] = t.dt.strftime("%Y-%m")
    df["season"] = pd.Categorical(df["month"].map(config.SEASONS), categories=config.SEASON_ORDER, ordered=True)
    df["iso_week"] = t.dt.isocalendar().week.astype(int)
    df["day_of_week"] = t.dt.day_name()
    df["hour"] = t.dt.hour
    df["is_weekend"] = t.dt.dayofweek >= 5
    df["day_night"] = np.where(df["is_day"] == 1, "Day", "Night")

    codes = df["weather_code"]
    df["condition"] = codes.map(lambda c: config.WMO_CODES.get(int(c), ("Unknown", "Unknown"))[0] if pd.notna(c) else np.nan)
    df["condition_group"] = codes.map(lambda c: config.WMO_CODES.get(int(c), ("Unknown", "Unknown"))[1] if pd.notna(c) else np.nan)

    df["is_rain_hour"] = df["precip_mm"] >= config.RAIN_HOUR_MM
    df["is_heavy_rain_hour"] = df["precip_mm"] >= config.HEAVY_RAIN_HOUR_MM
    df["beaufort"], df["beaufort_label"] = _beaufort(df["wind_kmh"])
    df["gust_factor"] = (df["gust_kmh"] / df["wind_kmh"].where(df["wind_kmh"] > 5)).round(3)
    df["sunshine_h"] = df["sunshine_s"] / 3600
    df["dewpoint_depression_c"] = df["temp_c"] - df["dew_point_c"]
    df["wind_chill_effect_c"] = df["feels_like_c"] - df["temp_c"]

    df["temp_band"] = pd.cut(df["temp_c"], [-np.inf, 0, 5, 10, 15, 20, 25, np.inf],
                             labels=["<0", "0-5", "5-10", "10-15", "15-20", "20-25", "25+"])
    df["rh_band"] = pd.cut(df["rh_pct"], [0, 60, 70, 80, 90, 95, 100.1], right=False,
                           labels=["<60", "60-70", "70-80", "80-90", "90-95", "95-100"])
    df["pressure_band"] = pd.cut(df["pressure_hpa"], [0, 990, 1000, 1010, 1020, 1030, 2000],
                                 labels=["<990", "990-1000", "1000-1010", "1010-1020", "1020-1030", "1030+"])
    df["cloud_band"] = pd.cut(df["cloud_pct"], [-0.1, 20, 70, 100.1], labels=["Clear (<20%)", "Partly (20-70%)", "Overcast (>70%)"])
    compass = np.array(["N", "NE", "E", "SE", "S", "SW", "W", "NW"])
    df["wind_dir_8"] = np.where(df["wind_dir_deg"].notna(),
                                compass[((df["wind_dir_deg"].fillna(0) + 22.5) // 45).astype(int) % 8], None)

    df = df.sort_values(["city", "time_utc"])
    g = df.groupby("city", sort=False)
    df["temp_change_1h"] = g["temp_c"].diff()
    df["pressure_tendency_3h"] = g["pressure_hpa"].diff(3)
    for col, w in [("temp_c", 24), ("temp_c", 168), ("rh_pct", 24), ("wind_kmh", 24), ("pressure_hpa", 24)]:
        df[f"{col}_roll{w}h"] = g[col].transform(lambda s: s.rolling(w, min_periods=int(w * 0.75)).mean())
    df["precip_roll24h_sum"] = g["precip_mm"].transform(lambda s: s.rolling(24, min_periods=18).sum())
    df["precip_roll168h_sum"] = g["precip_mm"].transform(lambda s: s.rolling(168, min_periods=126).sum())

    # Anomaly versus this city's own mean for the same month and hour (removes season + diurnal cycle)
    df["temp_anomaly_c"] = df["temp_c"] - df.groupby(["city", "month", "hour"])["temp_c"].transform("mean")
    return df.reset_index(drop=True)


def daily_aggregate(df: pd.DataFrame) -> pd.DataFrame:
    """Daily (local calendar day) metrics per city + climatological day flags."""
    agg = df.groupby(["city", "date"]).agg(
        hours=("temp_c", "count"),
        temp_mean=("temp_c", "mean"), temp_max=("temp_c", "max"), temp_min=("temp_c", "min"),
        feels_like_min=("feels_like_c", "min"),
        precip_sum=("precip_mm", lambda s: s.sum(min_count=18)),
        snow_sum=("snow_cm", "sum"), rain_hours=("is_rain_hour", "sum"),
        rh_mean=("rh_pct", "mean"), wind_mean=("wind_kmh", "mean"), wind_max=("wind_kmh", "max"),
        gust_max=("gust_kmh", "max"), pressure_mean=("pressure_hpa", "mean"),
        pressure_min=("pressure_hpa", "min"), cloud_mean=("cloud_pct", "mean"),
        sunshine_h=("sunshine_h", "sum"),
        condition_group=("condition_group", lambda s: s.mode().iat[0] if s.notna().any() else np.nan),
    ).reset_index()
    agg["date"] = pd.to_datetime(agg["date"])
    agg["is_full_day"] = agg["hours"] >= config.MIN_HOURS_FOR_FULL_DAY
    agg["temp_range"] = agg["temp_max"] - agg["temp_min"]
    agg["month"] = agg["date"].dt.month
    agg["month_name"] = agg["date"].dt.strftime("%b")
    agg["year_month"] = agg["date"].dt.strftime("%Y-%m")
    agg["season"] = pd.Categorical(agg["month"].map(config.SEASONS), categories=config.SEASON_ORDER, ordered=True)
    agg["wet_day"] = agg["precip_sum"] >= config.WET_DAY_MM
    agg["heavy_rain_day"] = agg["precip_sum"] >= config.HEAVY_RAIN_DAY_MM
    agg["frost_day"] = agg["temp_min"] < config.FROST_C
    agg["summer_day"] = agg["temp_max"] >= config.SUMMER_DAY_C
    agg["hot_day"] = agg["temp_max"] >= config.HOT_DAY_C
    agg["gale_gust_day"] = agg["gust_max"] >= config.GALE_GUST_KMH
    for key in ["nation", "lat", "lon"]:
        agg[key] = agg["city"].map(lambda c, k=key: config.CITIES[c][k])

    agg = agg.sort_values(["city", "date"])
    g = agg.groupby("city", sort=False)
    agg["temp_mean_roll7d"] = g["temp_mean"].transform(lambda s: s.rolling(7, min_periods=5).mean())
    agg["temp_mean_roll30d"] = g["temp_mean"].transform(lambda s: s.rolling(30, min_periods=21).mean())
    agg["precip_roll7d_sum"] = g["precip_sum"].transform(lambda s: s.rolling(7, min_periods=5).sum())
    agg["precip_roll30d_sum"] = g["precip_sum"].transform(lambda s: s.rolling(30, min_periods=21).sum())
    return agg.reset_index(drop=True)
