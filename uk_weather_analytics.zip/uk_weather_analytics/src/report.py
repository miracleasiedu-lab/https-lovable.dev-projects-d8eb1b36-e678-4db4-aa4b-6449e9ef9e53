"""Assemble outputs/report.md. All numeric statements come from the computed results."""
from __future__ import annotations

from datetime import datetime

import numpy as np
import pandas as pd

import config


def md_table(df: pd.DataFrame, max_rows: int = 30) -> str:
    if df is None or len(df) == 0:
        return "_(no rows)_"
    df = df.head(max_rows).copy()
    if not isinstance(df.index, pd.RangeIndex):
        df = df.reset_index()
    def cell(v):
        if isinstance(v, (float, np.floating)):
            return "" if pd.isna(v) else f"{v:,.2f}"
        if isinstance(v, pd.Timestamp):
            return v.strftime("%Y-%m-%d %H:%M")
        return str(v)
    head = "| " + " | ".join(map(str, df.columns)) + " |"
    sep = "|" + "---|" * len(df.columns)
    rows = ["| " + " | ".join(cell(v) for v in r) + " |" for r in df.itertuples(index=False)]
    return "\n".join([head, sep, *rows])


def _section(res: dict) -> str:
    parts = [f"### {res['id']}. {res['title']}", f"*Question:* {res['question']}", ""]
    if res.get("figure"):
        parts.append(f"![{res['title']}]({res['figure']})")
    parts += [f"- {f}" for f in res["findings"]]
    return "\n".join(parts) + "\n"


def build_insights(h, d, kpis, results, ext, cities) -> list[str]:
    """Cross-cutting insights, each derived from computed numbers."""
    by_id = {r["id"]: r for group in results.values() for r in group}
    pick = lambda i, k=0: by_id[i]["findings"][k] if i in by_id and len(by_id[i]["findings"]) > k else None
    ins = [
        pick("B8"), pick("B9"), pick("B2"), pick("B3"), pick("B7"), pick("U3", 2),
        pick("B6"), pick("B10"), pick("M8"), pick("M2"), pick("M7"), pick("T5", 1), pick("M9"),
        ext["findings"][4], cities["findings"][0],
    ]
    return [i for i in ins if i]


def build_recommendations(h, d, ext, cities) -> list[str]:
    th, cnt, t = ext["thresholds"], ext["counts"], cities["table"]
    recs = [
        "Use city-specific alert thresholds rather than one national value. The P99/P1 thresholds computed from this "
        "data (table below) differ by city, e.g. P99 gust ranges from "
        f"{th['gust_p99'].min():.0f} km/h ({th['gust_p99'].idxmin()}) to {th['gust_p99'].max():.0f} km/h ({th['gust_p99'].idxmax()}).",
        f"Prioritise wind monitoring for {cnt['gale_gust_day'].idxmax()} and {t['mean_wind_kmh'].idxmax()}, which recorded the most "
        "gale-force-gust days and the highest mean wind respectively.",
        f"Prioritise flood/drainage readiness for {t['total_rain_mm'].idxmax()} and {cnt['heavy_rain_day'].idxmax()} "
        "(highest total rainfall and most heavy-rain days).",
        f"Plan cold-weather operations (gritting, frost protection) around {cnt['frost_day'].idxmax()}, which had the most frost days.",
        *_signal_recommendations(h),
        "Extend the history to 5–10+ years before drawing conclusions about trends; one year captures the seasonal cycle, not climate change.",
        "Validate against Met Office station observations for any city where decisions depend on exact values (see limitations).",
    ]
    return recs


def _signal_recommendations(h) -> list[str]:
    """Recommend pressure/humidity signals only to the extent the data supports them."""
    recs = []
    pb = h.groupby("pressure_band", observed=True)["is_rain_hour"].mean().mul(100)
    pb = pb[h.groupby("pressure_band", observed=True).size() >= 100]
    if len(pb) >= 2:
        lo, hi = pb.iloc[0], pb.iloc[-1]
        if lo >= 2 * hi and lo - hi >= 10:
            recs.append(f"Add a low-pressure rain-risk flag: hours in the {pb.index[0]} hPa band had rain {lo:.0f}% of the time versus "
                        f"{hi:.0f}% in the {pb.index[-1]} hPa band, a usable early-warning signal alongside forecasts.")
        else:
            recs.append(f"Do not rely on pressure alone as a rain signal: rain frequency was {lo:.0f}% in the {pb.index[0]} hPa band and "
                        f"{hi:.0f}% in the {pb.index[-1]} hPa band, too small a separation in this data.")
    rb = h.groupby("rh_band", observed=True)["is_rain_hour"].mean().mul(100)
    share_humid = (h["rh_pct"] >= 90).mean() * 100
    if len(rb) >= 2:
        recs.append(f"Treat humidity as a supporting signal: rain frequency was {rb.iloc[-1]:.0f}% at {rb.index[-1]}% RH versus "
                    f"{rb.iloc[0]:.0f}% below {rb.index[0][1:]}%, but {share_humid:.0f}% of all hours were at or above 90% RH, "
                    "so a humidity-only trigger would fire often.")
    return recs


LIMITATIONS = [
    "Open-Meteo's historical data is model reanalysis (ERA5-family, roughly 9–25 km grid), not a weather-station record. "
    "Values represent a grid cell, so coastal, urban-heat-island and hilly effects are smoothed; city centres may be warmer and local "
    "downpours sharper than shown. The grid elevation of each cell is recorded in the data-quality table.",
    "Reanalysis precipitation and cloud cover are less reliable than temperature and pressure; convective summer showers are especially underrepresented.",
    "One year of data describes that year only. Monthly anomalies are relative to the study period, not a 1991–2020 normal, and any linear trend over 12 months is dominated by the seasonal cycle.",
    "City comparisons use one point per city; with 12 cities, cross-city correlations (latitude, longitude) are descriptive, not statistically robust.",
    "Weather codes in the archive are derived from model fields, so categories such as fog or thunderstorm are approximate.",
    "Live 'current' values are 15-minute model analyses from the forecast API and may differ from the archive and from observations.",
    "Thresholds (wet day ≥1 mm, heavy rain ≥10 mm/day, gale gust ≥62 km/h) are conventional choices set in config.py; changing them changes counts.",
]


def write_report(*, start, end, h, d, units, quality, cleaning_log, kpis, results, ext, cities, failures) -> str:
    q = quality["summary"]
    lines = [
        "# Live UK Weather Analytics: Analysis Report",
        f"_Generated {datetime.now():%d %b %Y %H:%M} from Open-Meteo API data. Every number below is calculated by `run_pipeline.py`._",
        "",
        "## 1. Data source and coverage",
        f"- Historical: Open-Meteo Archive API (`{config.ARCHIVE_URL}`), hourly, {start} to {end} (UTC), {h['city'].nunique()} cities.",
        f"- Live: Open-Meteo Forecast API `current` block (`{config.FORECAST_URL}`), used by the dashboard.",
        f"- Rows after cleaning: {len(h):,} hourly city-records; {len(d):,} full city-days (≥{config.MIN_HOURS_FOR_FULL_DAY} h).",
        f"- Units reported by the API: " + ", ".join(f"{k}: {v}" for k, v in units.items() if k != "time") + ".",
    ]
    if failures:
        lines.append(f"- **Cities that failed to download and are excluded:** {', '.join(f'{c} ({e})' for c, e in failures.items())}.")
    lines += ["", "## 2. Data quality assessment", md_table(q), "",
              "Missing values by variable (% of rows):", md_table(quality["missing_pct"]), "",
              "Out-of-range values (outside plausible UK limits in config.py):", md_table(quality["out_of_range"]), "",
              "Internal consistency checks (counts of violating hours):", md_table(quality["consistency"]), "",
              "## 3. Cleaning log",
              *[f"- {k.replace('_', ' ')}: {({kk: vv for kk, vv in v.items() if vv} or 'none') if isinstance(v, dict) else v}"
                for k, v in cleaning_log.items()], "",
              "## 4. Feature engineering",
              "Local time (Europe/London, DST-aware), date, month, meteorological season, ISO week, weekday/weekend, hour, day/night; "
              "WMO condition and group; rain-hour and heavy-rain-hour flags; Beaufort force; gust factor; sunshine hours; dew-point depression; "
              "temperature/humidity/pressure/cloud bands; 8-point wind direction; 1-h temperature change; 3-h pressure tendency; "
              "24-h and 168-h rolling means; 24-h/168-h rolling rainfall; temperature anomaly vs city-month-hour mean; daily aggregates with "
              "wet/heavy-rain/frost/summer/hot/gale-gust day flags and 7/30-day rolling means.", "",
              "## 5. Key performance indicators", md_table(kpis), ""]
    for title, key in [("6. Univariate analysis", "univariate"), ("7. Bivariate analysis", "bivariate"),
                       ("8. Multivariate analysis", "multivariate"), ("9. Time-series analysis", "time_series")]:
        lines += [f"## {title}", *[_section(r) for r in results[key]]]
    lines += ["## 10. Extreme weather", f"![Extreme days]({ext['figure']})", *[f"- {f}" for f in ext["findings"]], "",
              "Day counts by city:", md_table(ext["counts"]), ""]
    for name, tbl in ext["tables"].items():
        lines += [f"**{name.replace('_', ' ').title()}**", md_table(tbl), ""]
    lines += ["## 11. City comparison", f"![City profile]({cities['figure']})", *[f"- {f}" for f in cities["findings"]], "",
              md_table(cities["table"]), "", "Seasonal mean temperature (°C):", md_table(cities["seasonal_temp"]), "",
              "## 12. Key insights", *[f"{i}. {s}" for i, s in enumerate(build_insights(h, d, kpis, results, ext, cities), 1)], "",
              "## 13. Recommendations for the operations team",
              *[f"{i}. {s}" for i, s in enumerate(build_recommendations(h, d, ext, cities), 1)], "",
              "Suggested city alert thresholds (percentiles of the study period):", md_table(ext["thresholds"]), "",
              "## 14. Limitations", *[f"- {s}" for s in LIMITATIONS], "",
              "## 15. Conclusion", _conclusion(h, d, kpis, cities), ""]
    text = "\n".join(lines)
    (config.OUTPUT_DIR / "report.md").write_text(text, encoding="utf-8")
    return text


def _conclusion(h, d, kpis, cities) -> str:
    k = kpis.set_index("kpi")
    t = cities["table"]
    explained = 100 * (1 - h["temp_anomaly_c"].var() / h["temp_c"].var())
    return (
        f"Using {len(h):,} hourly records for {h['city'].nunique()} UK cities, the analysis found an average temperature of "
        f"{k.at['Average temperature', 'value']:.1f} °C, a mean of {k.at['Total rainfall (mean per city)', 'value']:.0f} mm of rain per city and "
        f"{k.at['Rainy days (≥1 mm, mean per city)', 'value']:.0f} wet days per city. Across cities, "
        f"{t['mean_temp_c'].idxmax()} was warmest, {t['mean_temp_c'].idxmin()} coolest, {t['total_rain_mm'].idxmax()} wettest and "
        f"{t['mean_wind_kmh'].idxmax()} windiest. The city, month and hour together account for {explained:.0f}% of the variance in hourly "
        "temperature; the remainder is day-to-day weather. The Streamlit dashboard puts these historical baselines next to live conditions so the team can see at a glance "
        "whether current weather is unusual for each city."
    )
