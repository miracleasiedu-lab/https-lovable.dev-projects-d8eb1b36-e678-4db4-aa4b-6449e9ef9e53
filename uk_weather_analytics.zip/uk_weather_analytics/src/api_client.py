"""Open-Meteo API connection layer.

* Historical hourly data -> Archive API (one request per city, raw JSON cached to disk)
* Live conditions        -> Forecast API `current=` block (all cities in one request)

No API key is required. Free use is limited to non-commercial purposes and roughly
10,000 calls/day, so historical responses are cached and re-used.
"""
from __future__ import annotations

import json
import logging
import time
from datetime import date, datetime, timezone
from pathlib import Path

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

import config

log = logging.getLogger(__name__)


class OpenMeteoError(RuntimeError):
    """Raised when the API returns an error payload or a non-200 status."""


def make_session() -> requests.Session:
    session = requests.Session()
    retry = Retry(total=5, backoff_factor=1.5, status_forcelist=[429, 500, 502, 503, 504],
                  allowed_methods=["GET"], respect_retry_after_header=True)
    session.mount("https://", HTTPAdapter(max_retries=retry))
    session.headers["User-Agent"] = "uk-weather-analytics/1.0 (portfolio project)"
    return session


def _get_json(session: requests.Session, url: str, params: dict, timeout: int = 90):
    response = session.get(url, params=params, timeout=timeout)
    try:
        payload = response.json()
    except ValueError as exc:
        raise OpenMeteoError(f"Non-JSON response ({response.status_code}): {response.text[:200]}") from exc
    if response.status_code != 200 or (isinstance(payload, dict) and payload.get("error")):
        reason = payload.get("reason") if isinstance(payload, dict) else payload
        raise OpenMeteoError(f"HTTP {response.status_code}: {reason}")
    return payload


def _slug(name: str) -> str:
    return name.lower().replace(" ", "_")


# ---------------------------------------------------------------- historical
def fetch_historical_city(city: str, start: date, end: date, variables=None,
                          session: requests.Session | None = None,
                          cache_dir: Path = config.RAW_DIR, force: bool = False) -> dict:
    """Fetch hourly archive data for one city. Returns the raw JSON payload (dict)."""
    variables = variables or config.HOURLY_VARS
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_file = cache_dir / f"{_slug(city)}_{start}_{end}.json"
    if cache_file.exists() and not force:
        log.info("Using cached JSON for %s (%s)", city, cache_file.name)
        return json.loads(cache_file.read_text())

    meta = config.CITIES[city]
    params = {
        "latitude": meta["lat"], "longitude": meta["lon"],
        "start_date": str(start), "end_date": str(end),
        "hourly": ",".join(variables),
        "timezone": "UTC",            # fetch in UTC, convert locally -> no DST ambiguity
        "wind_speed_unit": "kmh", "temperature_unit": "celsius", "precipitation_unit": "mm",
    }
    session = session or make_session()
    payload = _get_json(session, config.ARCHIVE_URL, params)
    payload["_meta"] = {
        "city": city, "requested_lat": meta["lat"], "requested_lon": meta["lon"],
        "fetched_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source": config.ARCHIVE_URL, "params": params,
    }
    cache_file.write_text(json.dumps(payload))
    log.info("Fetched %s: %d hourly rows", city, len(payload.get("hourly", {}).get("time", [])))
    return payload


def fetch_historical_all(cities=None, start: date = config.DEFAULT_START, end: date = config.DEFAULT_END,
                         force: bool = False, pause_s: float = 1.0) -> tuple[dict, dict]:
    """Fetch every city. Returns ({city: payload}, {city: error message})."""
    cities = cities or list(config.CITIES)
    session = make_session()
    payloads, failures = {}, {}
    for city in cities:
        try:
            cached = (config.RAW_DIR / f"{_slug(city)}_{start}_{end}.json").exists()
            payloads[city] = fetch_historical_city(city, start, end, session=session, force=force)
            if not cached or force:
                time.sleep(pause_s)  # be polite to the free API
        except (OpenMeteoError, requests.RequestException) as exc:
            log.error("Failed to fetch %s: %s", city, exc)
            failures[city] = str(exc)
    return payloads, failures


# ---------------------------------------------------------------- live
def fetch_live(cities=None, session: requests.Session | None = None) -> list[dict]:
    """One request for all cities: current conditions + yesterday/today hourly series."""
    cities = cities or list(config.CITIES)
    params = {
        "latitude": ",".join(str(config.CITIES[c]["lat"]) for c in cities),
        "longitude": ",".join(str(config.CITIES[c]["lon"]) for c in cities),
        "current": ",".join(config.CURRENT_VARS),
        "hourly": ",".join(config.LIVE_HOURLY_VARS),
        "past_days": 1, "forecast_days": 2,
        "timezone": "UTC", "wind_speed_unit": "kmh",
    }
    session = session or make_session()
    payload = _get_json(session, config.FORECAST_URL, params, timeout=30)
    payloads = payload if isinstance(payload, list) else [payload]
    if len(payloads) != len(cities):
        raise OpenMeteoError(f"Expected {len(cities)} locations, got {len(payloads)}")
    for city, p in zip(cities, payloads):     # API preserves request order
        p["_meta"] = {"city": city, "fetched_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    return payloads


def live_current_to_df(payloads: list[dict]) -> pd.DataFrame:
    """JSON `current` blocks -> one tidy row per city."""
    rows = []
    for p in payloads:
        cur = dict(p["current"])
        cur["city"] = p["_meta"]["city"]
        cur["fetched_at_utc"] = p["_meta"]["fetched_at_utc"]
        rows.append(cur)
    df = pd.DataFrame(rows).rename(columns=config.RENAME)
    df["time_utc"] = pd.to_datetime(df.pop("time"), utc=True)
    df["time_local"] = df["time_utc"].dt.tz_convert(config.LOCAL_TZ)
    df["condition"] = df["weather_code"].map(lambda c: config.WMO_CODES.get(int(c), ("Unknown", "Unknown"))[0]
                                             if pd.notna(c) else "Unknown")
    df["lat"] = df["city"].map(lambda c: config.CITIES[c]["lat"])
    df["lon"] = df["city"].map(lambda c: config.CITIES[c]["lon"])
    return df.drop(columns=["interval"], errors="ignore")


def live_hourly_to_df(payloads: list[dict]) -> pd.DataFrame:
    """JSON `hourly` blocks (yesterday -> tomorrow) -> long DataFrame."""
    frames = []
    for p in payloads:
        h = pd.DataFrame(p["hourly"]).rename(columns=config.RENAME)
        h["time_utc"] = pd.to_datetime(h.pop("time"), utc=True)
        h["time_local"] = h["time_utc"].dt.tz_convert(config.LOCAL_TZ)
        h["city"] = p["_meta"]["city"]
        frames.append(h)
    return pd.concat(frames, ignore_index=True)
