"""All analytical calculations for the report.

Every analysis returns a dict:
    {"id", "title", "question", "figure" (path or None), "findings" [str], "table" (DataFrame or None)}
Findings are sentences assembled from computed values only; nothing is hard-coded.
"""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import config

plt.rcParams.update({
    "figure.figsize": (9, 4.8), "figure.dpi": 110, "axes.spines.top": False,
    "axes.spines.right": False, "axes.grid": True, "grid.alpha": 0.25,
    "axes.titleweight": "bold", "axes.titlesize": 12, "font.size": 10,
})
CITY_COLORS = ["#332288", "#117733", "#44AA99", "#88CCEE", "#DDCC77", "#CC6677",
               "#AA4499", "#882255", "#E69F00", "#56B4E9", "#009E73", "#999999"]
SEASON_COLORS = {"Winter": "#2F6690", "Spring": "#3A7D44", "Summer": "#D1A01F", "Autumn": "#B3541E"}
MAIN = "#2F6690"


# ---------------------------------------------------------------- helpers
def _save(fig, name: str) -> str:
    config.FIG_DIR.mkdir(parents=True, exist_ok=True)
    path = config.FIG_DIR / f"{name}.png"
    fig.tight_layout()
    fig.savefig(path, dpi=130, bbox_inches="tight")
    plt.close(fig)
    return str(path.relative_to(config.OUTPUT_DIR))


def describe(s: pd.Series) -> dict:
    s = s.dropna().astype(float)
    return {"n": len(s), "mean": s.mean(), "median": s.median(), "std": s.std(), "min": s.min(),
            "p05": s.quantile(.05), "p25": s.quantile(.25), "p75": s.quantile(.75),
            "p95": s.quantile(.95), "max": s.max(), "skew": s.skew(), "kurtosis": s.kurt()}


def strength(r: float) -> str:
    a = abs(r)
    word = "negligible" if a < .1 else "weak" if a < .3 else "moderate" if a < .5 else "strong" if a < .7 else "very strong"
    return f"{word} {'positive' if r > 0 else 'negative'}" if a >= .1 else word


def corr_pair(df, x, y) -> tuple[float, float]:
    sub = df[[x, y]].dropna()
    return sub[x].corr(sub[y]), sub[x].corr(sub[y], method="spearman")


def fmt_time(ts) -> str:
    return pd.Timestamp(ts).strftime("%d %b %Y %H:%M")


def fmt_date(ts) -> str:
    return pd.Timestamp(ts).strftime("%d %b %Y")


def result(id_, title, question, figure, findings, table=None) -> dict:
    return {"id": id_, "title": title, "question": question, "figure": figure, "findings": findings, "table": table}


def month_order(df):
    return [m for m in ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
            if m in set(df["month_name"])]


def city_totals(d: pd.DataFrame) -> pd.Series:
    return d.groupby("city")["precip_sum"].sum()


# ================================================================ KPIs
def compute_kpis(h: pd.DataFrame, d: pd.DataFrame) -> pd.DataFrame:
    city_mean_t = h.groupby("city")["temp_c"].mean()
    totals = city_totals(d)
    wet = d.groupby("city")["wet_day"].sum()
    imax, imin = h["temp_c"].idxmax(), h["temp_c"].idxmin()
    iwind, igust = h["wind_kmh"].idxmax(), h["gust_kmh"].idxmax()
    rows = [
        ("Average temperature", h["temp_c"].mean(), "°C", f"Mean of {h['temp_c'].count():,} hourly values across {h['city'].nunique()} cities"),
        ("Maximum temperature", h.at[imax, "temp_c"], "°C", f"{h.at[imax, 'city']}, {fmt_time(h.at[imax, 'time_local'])}"),
        ("Minimum temperature", h.at[imin, "temp_c"], "°C", f"{h.at[imin, 'city']}, {fmt_time(h.at[imin, 'time_local'])}"),
        ("Total rainfall (mean per city)", totals.mean(), "mm", f"All-city sum {totals.sum():,.0f} mm; range {totals.min():.0f}–{totals.max():.0f} mm"),
        ("Average relative humidity", h["rh_pct"].mean(), "%", f"Median {h['rh_pct'].median():.0f}%"),
        ("Average wind speed", h["wind_kmh"].mean(), "km/h", f"Median {h['wind_kmh'].median():.1f} km/h at 10 m"),
        ("Maximum wind speed", h.at[iwind, "wind_kmh"], "km/h", f"{h.at[iwind, 'city']}, {fmt_time(h.at[iwind, 'time_local'])}; max gust {h.at[igust, 'gust_kmh']:.0f} km/h ({h.at[igust, 'city']})"),
        ("Average pressure (MSL)", h["pressure_hpa"].mean(), "hPa", f"Range {h['pressure_hpa'].min():.0f}–{h['pressure_hpa'].max():.0f} hPa"),
        ("Rainy days (≥1 mm, mean per city)", wet.mean(), "days", f"Range {wet.min()} ({wet.idxmin()}) – {wet.max()} ({wet.idxmax()}) of {d.groupby('city').size().max()} full days"),
        ("Hottest location", city_mean_t.max(), "°C", f"{city_mean_t.idxmax()} (highest mean temperature)"),
        ("Coldest location", city_mean_t.min(), "°C", f"{city_mean_t.idxmin()} (lowest mean temperature)"),
        ("Wettest location", totals.max(), "mm", f"{totals.idxmax()} (driest: {totals.idxmin()}, {totals.min():.0f} mm)"),
    ]
    k = pd.DataFrame(rows, columns=["kpi", "value", "unit", "detail"])
    k["value"] = k["value"].astype(float).round(1)
    return k


# ================================================================ Univariate
def univariate(h: pd.DataFrame, d: pd.DataFrame) -> list[dict]:
    out = []

    s = describe(h["temp_c"])
    fig, ax = plt.subplots()
    ax.hist(h["temp_c"].dropna(), bins=np.arange(np.floor(s["min"]), np.ceil(s["max"]) + 1, 1), color=MAIN, alpha=.85)
    ax.axvline(s["mean"], color="k", ls="--", label=f"mean {s['mean']:.1f}")
    ax.axvline(s["median"], color="#B3541E", ls=":", label=f"median {s['median']:.1f}")
    ax.set(title="Hourly temperature distribution", xlabel="°C", ylabel="Hours"); ax.legend()
    out.append(result("U1", "Temperature distribution", "How are hourly temperatures distributed?", _save(fig, "U1_temperature_hist"), [
        f"Hourly temperature averaged {s['mean']:.1f} °C (median {s['median']:.1f} °C, SD {s['std']:.1f} °C), with 90% of hours between {s['p05']:.1f} and {s['p95']:.1f} °C.",
        f"Skewness is {s['skew']:.2f}; {100 * (h['temp_c'] < 0).mean():.1f}% of hours were below freezing and {100 * (h['temp_c'] >= 25).mean():.1f}% at or above 25 °C.",
    ], pd.DataFrame([s]).round(2)))

    s = describe(h["rh_pct"])
    fig, ax = plt.subplots()
    ax.hist(h["rh_pct"].dropna(), bins=np.arange(0, 102, 2), color="#3A7D7C")
    ax.set(title="Relative humidity distribution", xlabel="%", ylabel="Hours")
    out.append(result("U2", "Relative humidity distribution", "How humid is the UK hour-to-hour?", _save(fig, "U2_humidity_hist"), [
        f"Median relative humidity was {s['median']:.0f}% (mean {s['mean']:.1f}%, skew {s['skew']:.2f}).",
        f"{100 * (h['rh_pct'] >= 90).mean():.1f}% of hours were at or above 90% RH; only {100 * (h['rh_pct'] < 60).mean():.1f}% fell below 60%.",
    ], pd.DataFrame([s]).round(2)))

    wet = h.loc[h["is_rain_hour"], "precip_mm"]
    sw = describe(wet)
    top10 = wet.sort_values(ascending=False)
    share_top10 = top10.head(max(1, int(len(top10) * .1))).sum() / wet.sum() * 100 if wet.sum() else np.nan
    fig, ax = plt.subplots()
    ax.hist(wet, bins=50, color="#2F6690"); ax.set_yscale("log")
    ax.set(title="Hourly precipitation intensity (hours ≥0.1 mm)", xlabel="mm per hour", ylabel="Hours (log)")
    out.append(result("U3", "Rainfall intensity distribution", "When it rains, how hard does it rain?", _save(fig, "U3_precip_intensity"), [
        f"{100 * h['is_rain_hour'].mean():.1f}% of hours recorded ≥{config.RAIN_HOUR_MM} mm of precipitation.",
        f"In those hours the median rate was {sw['median']:.2f} mm/h and the 95th percentile {sw['p95']:.2f} mm/h; {100 * h['is_heavy_rain_hour'].mean():.2f}% of all hours reached the heavy-rain rate of {config.HEAVY_RAIN_HOUR_MM} mm/h.",
        f"The wettest 10% of rain hours delivered {share_top10:.0f}% of all rainfall, so rainfall is "
        f"{'strongly concentrated in a few intense hours' if share_top10 >= 40 else 'moderately concentrated' if share_top10 >= 25 else 'fairly evenly spread across rain hours'} (skew {sw['skew']:.2f}).",
    ], pd.DataFrame([sw]).round(3)))

    s = describe(h["wind_kmh"])
    fig, ax = plt.subplots()
    ax.hist(h["wind_kmh"].dropna(), bins=60, color="#556B7D")
    ax.axvline(s["p95"], color="#B3541E", ls="--", label=f"P95 {s['p95']:.0f} km/h"); ax.legend()
    ax.set(title="Hourly wind speed (10 m)", xlabel="km/h", ylabel="Hours")
    out.append(result("U4", "Wind speed distribution", "What wind speeds are typical and what is unusual?", _save(fig, "U4_wind_hist"), [
        f"Mean wind speed was {s['mean']:.1f} km/h (median {s['median']:.1f}); the distribution is right-skewed (skew {s['skew']:.2f}).",
        f"The 95th percentile was {s['p95']:.1f} km/h; {100 * (h['wind_kmh'] >= 39).mean():.2f}% of hours reached a strong breeze (≥39 km/h, Beaufort 6).",
    ], pd.DataFrame([s]).round(2)))

    s = describe(h["pressure_hpa"])
    fig, ax = plt.subplots()
    ax.hist(h["pressure_hpa"].dropna(), bins=60, color="#6C5B7B")
    ax.axvline(1013.25, color="k", ls=":", label="Standard 1013.25 hPa"); ax.legend()
    ax.set(title="Mean sea-level pressure", xlabel="hPa", ylabel="Hours")
    out.append(result("U5", "Atmospheric pressure distribution", "How variable is surface pressure?", _save(fig, "U5_pressure_hist"), [
        f"MSL pressure averaged {s['mean']:.1f} hPa (SD {s['std']:.1f}), ranging {s['min']:.1f}–{s['max']:.1f} hPa.",
        f"{100 * (h['pressure_hpa'] < 1000).mean():.1f}% of hours were below 1000 hPa (typical of active low-pressure systems); skew {s['skew']:.2f}.",
    ], pd.DataFrame([s]).round(2)))

    s = describe(h["cloud_pct"])
    fig, ax = plt.subplots()
    ax.hist(h["cloud_pct"].dropna(), bins=np.arange(0, 105, 5), color="#8D99AE")
    ax.set(title="Cloud cover distribution", xlabel="% of sky", ylabel="Hours")
    out.append(result("U6", "Cloud cover distribution", "Is the sky usually clear, broken or overcast?", _save(fig, "U6_cloud_hist"), [
        f"Mean cloud cover was {s['mean']:.0f}% (median {s['median']:.0f}%).",
        f"{100 * (h['cloud_pct'] > 80).mean():.1f}% of hours were more than 80% cloudy, {100 * (h['cloud_pct'] < 20).mean():.1f}% under 20% and {100 * h['cloud_pct'].between(20, 80).mean():.1f}% in between.",
    ], pd.DataFrame([s]).round(2)))

    vc = h["condition_group"].value_counts(normalize=True).mul(100)
    fig, ax = plt.subplots()
    vc.sort_values().plot.barh(ax=ax, color=MAIN)
    ax.set(title="Weather condition frequency (WMO code groups)", xlabel="% of hours")
    detail = h["condition"].value_counts(normalize=True).mul(100).round(2).rename("pct_hours").to_frame()
    out.append(result("U7", "Weather conditions", "Which weather types dominate?", _save(fig, "U7_conditions_bar"), [
        f"The most frequent condition group was {vc.index[0]} ({vc.iloc[0]:.1f}% of hours), followed by {vc.index[1]} ({vc.iloc[1]:.1f}%).",
        "Groups: " + ", ".join(f"{k} {v:.1f}%" for k, v in vc.items()) + ".",
        f"Most common single code: {detail.index[0]} ({detail.iloc[0, 0]:.1f}%).",
    ], detail.head(15)))

    bf = h["beaufort_label"].value_counts(normalize=True).mul(100).sort_index()
    bf = bf[bf > 0]
    fig, ax = plt.subplots()
    bf.plot.bar(ax=ax, color="#556B7D"); ax.set(title="Beaufort force frequency", ylabel="% of hours", xlabel="")
    plt.setp(ax.get_xticklabels(), rotation=35, ha="right")
    out.append(result("U8", "Beaufort wind classes", "How often do operationally relevant wind classes occur?", _save(fig, "U8_beaufort_bar"), [
        f"The modal class was {bf.idxmax()} ({bf.max():.1f}% of hours).",
        f"Force 7 or above (≥50 km/h sustained) occurred in {100 * (h['beaufort'] >= 7).mean():.2f}% of hours.",
    ], bf.round(2).rename("pct_hours").to_frame()))

    s = describe(d["temp_range"])
    imax = d["temp_range"].idxmax()
    fig, ax = plt.subplots()
    ax.hist(d["temp_range"].dropna(), bins=40, color="#B3541E")
    ax.set(title="Daily temperature range (max − min)", xlabel="°C", ylabel="City-days")
    out.append(result("U9", "Daily temperature range", "How much do temperatures swing within a day?", _save(fig, "U9_daily_range_hist"), [
        f"The mean daily range was {s['mean']:.1f} °C (median {s['median']:.1f}, P95 {s['p95']:.1f} °C).",
        f"The largest swing was {s['max']:.1f} °C in {d.at[imax, 'city']} on {fmt_date(d.at[imax, 'date'])}.",
    ], pd.DataFrame([s]).round(2)))

    wd = d.loc[d["wet_day"], "precip_sum"]
    s = describe(wd)
    imax = d["precip_sum"].idxmax()
    fig, ax = plt.subplots()
    ax.hist(wd, bins=40, color="#2F6690")
    ax.axvline(config.HEAVY_RAIN_DAY_MM, color="#B3541E", ls="--", label=f"heavy ≥{config.HEAVY_RAIN_DAY_MM:.0f} mm"); ax.legend()
    ax.set(title="Daily rainfall on wet days (≥1 mm)", xlabel="mm per day", ylabel="City-days")
    out.append(result("U10", "Daily rainfall totals", "How much rain falls on a wet day?", _save(fig, "U10_daily_rain_hist"), [
        f"{100 * d['wet_day'].mean():.1f}% of city-days were wet (≥{config.WET_DAY_MM:.0f} mm); median wet-day total {s['median']:.1f} mm, P95 {s['p95']:.1f} mm.",
        f"The wettest day was {d.at[imax, 'precip_sum']:.1f} mm in {d.at[imax, 'city']} on {fmt_date(d.at[imax, 'date'])}; {100 * d['heavy_rain_day'].mean():.1f}% of city-days had ≥{config.HEAVY_RAIN_DAY_MM:.0f} mm.",
    ], pd.DataFrame([s]).round(2)))
    return out


# ================================================================ Bivariate
def bivariate(h: pd.DataFrame, d: pd.DataFrame) -> list[dict]:
    out = []
    months = month_order(h)

    r, rho = corr_pair(h, "temp_c", "rh_pct")
    fig, ax = plt.subplots()
    hb = ax.hexbin(h["temp_c"], h["rh_pct"], gridsize=50, cmap="Blues", mincnt=1, bins="log")
    fig.colorbar(hb, label="Hours (log)"); ax.set(title="Temperature vs relative humidity", xlabel="°C", ylabel="RH %")
    tb = h.groupby("temp_band", observed=True)["rh_pct"].mean()
    out.append(result("B1", "Temperature vs humidity", "Does humidity fall as temperature rises?", _save(fig, "B1_temp_vs_rh"), [
        f"Pearson r = {r:.2f}, Spearman ρ = {rho:.2f}: a {strength(r)} relationship.",
        f"Mean RH was {tb.iloc[0]:.0f}% in the {tb.index[0]} °C band and {tb.iloc[-1]:.0f}% in the {tb.index[-1]} °C band.",
    ], tb.round(1).to_frame("mean_rh_pct")))

    fig, ax = plt.subplots()
    data = [d.loc[d["month_name"] == m, "temp_mean"].dropna() for m in months]
    ax.boxplot(data, tick_labels=months, showfliers=False, patch_artist=True, boxprops=dict(facecolor="#CFE0EC"))
    ax.set(title="Daily mean temperature by month (all cities)", ylabel="°C")
    mm = d.groupby("month_name")["temp_mean"].mean().reindex(months)
    out.append(result("B2", "Temperature by month", "How strong is the seasonal cycle?", _save(fig, "B2_temp_by_month"), [
        f"The warmest month was {mm.idxmax()} ({mm.max():.1f} °C mean) and the coldest {mm.idxmin()} ({mm.min():.1f} °C), a seasonal amplitude of {mm.max() - mm.min():.1f} °C.",
    ], mm.round(2).to_frame("mean_temp_c")))

    monthly = d.groupby(["city", "year_month", "month_name"])["precip_sum"].sum().reset_index()
    mr = monthly.groupby("month_name")["precip_sum"].mean().reindex(months)
    wet_share = d.groupby("month_name")["wet_day"].mean().mul(100).reindex(months)
    fig, ax = plt.subplots()
    ax.bar(mr.index, mr.values, color="#2F6690"); ax2 = ax.twinx(); ax2.plot(wet_share.index, wet_share.values, "o-", color="#B3541E")
    ax.set(title="Rainfall by month (mean city total) and % wet days", ylabel="mm"); ax2.set_ylabel("% wet days", color="#B3541E"); ax2.grid(False)
    out.append(result("B3", "Rainfall by month", "Which months are wettest?", _save(fig, "B3_rain_by_month"), [
        f"The wettest month was {mr.idxmax()} ({mr.max():.0f} mm average per city) and the driest {mr.idxmin()} ({mr.min():.0f} mm).",
        f"Wet-day frequency peaked in {wet_share.idxmax()} ({wet_share.max():.0f}% of days) and was lowest in {wet_share.idxmin()} ({wet_share.min():.0f}%).",
    ], pd.DataFrame({"mean_city_total_mm": mr.round(1), "wet_day_pct": wet_share.round(1)})))

    r, rho = corr_pair(h, "pressure_hpa", "wind_kmh")
    pb = h.groupby("pressure_band", observed=True)["wind_kmh"].mean()
    fig, ax = plt.subplots()
    hb = ax.hexbin(h["pressure_hpa"], h["wind_kmh"], gridsize=50, cmap="Purples", mincnt=1, bins="log")
    fig.colorbar(hb, label="Hours (log)"); ax.set(title="Pressure vs wind speed", xlabel="hPa", ylabel="km/h")
    out.append(result("B4", "Pressure vs wind", "Are low-pressure hours windier?", _save(fig, "B4_pressure_vs_wind"), [
        f"Pearson r = {r:.2f} (Spearman {rho:.2f}): {strength(r)}.",
        f"Mean wind was {pb.iloc[0]:.1f} km/h when pressure was {pb.index[0]} hPa versus {pb.iloc[-1]:.1f} km/h at {pb.index[-1]} hPa.",
    ], pb.round(2).to_frame("mean_wind_kmh")))

    r, rho = corr_pair(d, "cloud_mean", "temp_range")
    fig, ax = plt.subplots()
    ax.scatter(d["cloud_mean"], d["temp_range"], s=5, alpha=.25, color="#556B7D")
    ax.set(title="Daily cloud cover vs daily temperature range", xlabel="Mean cloud %", ylabel="Max − min °C")
    cq = d.assign(cb=pd.cut(d["cloud_mean"], [-1, 25, 50, 75, 101], labels=["0-25", "25-50", "50-75", "75-100"])).groupby("cb", observed=True)["temp_range"].mean()
    out.append(result("B5", "Cloud cover vs daily temperature range", "Do cloudy days have smaller temperature swings?", _save(fig, "B5_cloud_vs_dtr"), [
        f"Pearson r = {r:.2f} (Spearman {rho:.2f}): {strength(r)}.",
        f"Days averaging 0–25% cloud had a mean range of {cq.iloc[0]:.1f} °C versus {cq.iloc[-1]:.1f} °C for 75–100% cloud.",
    ], cq.round(2).to_frame("mean_temp_range_c")))

    rp = h.groupby("rh_band", observed=True)["is_rain_hour"].mean().mul(100)
    fig, ax = plt.subplots()
    rp.plot.bar(ax=ax, color="#3A7D7C"); ax.set(title="Probability of rain by humidity band", xlabel="RH %", ylabel="% of hours with rain")
    out.append(result("B6", "Humidity vs rain probability", "How does the chance of rain change with humidity?", _save(fig, "B6_rh_vs_rain_prob"), [
        f"Rain occurred in {rp.iloc[0]:.1f}% of hours with RH {rp.index[0]}% versus {rp.iloc[-1]:.1f}% at {rp.index[-1]}%.",
        f"Point-biserial correlation between RH and rain occurrence: r = {h['rh_pct'].corr(h['is_rain_hour'].astype(float)):.2f}.",
    ], rp.round(2).to_frame("rain_hour_pct")))

    dc = h.groupby("hour")["temp_c"].mean()
    fig, ax = plt.subplots()
    ax.plot(dc.index, dc.values, "o-", color="#B3541E"); ax.set(title="Mean temperature by local hour", xlabel="Hour", ylabel="°C", xticks=range(0, 24, 2))
    out.append(result("B7", "Diurnal temperature cycle", "When is it warmest and coldest during the day?", _save(fig, "B7_diurnal_cycle"), [
        f"Mean temperature peaked at {dc.idxmax():02d}:00 ({dc.max():.1f} °C) and bottomed at {dc.idxmin():02d}:00 ({dc.min():.1f} °C): an average diurnal amplitude of {dc.max() - dc.min():.1f} °C.",
    ], dc.round(2).to_frame("mean_temp_c")))

    order = d.groupby("city")["temp_mean"].median().sort_values().index
    fig, ax = plt.subplots()
    ax.boxplot([d.loc[d["city"] == c, "temp_mean"].dropna() for c in order], tick_labels=order, showfliers=False,
               patch_artist=True, boxprops=dict(facecolor="#F2D7C9"))
    ax.set(title="Daily mean temperature by city", ylabel="°C"); plt.setp(ax.get_xticklabels(), rotation=35, ha="right")
    ct = d.groupby("city")["temp_mean"].agg(["mean", "std"]).sort_values("mean")
    out.append(result("B8", "Temperature by city", "How do cities differ in temperature?", _save(fig, "B8_temp_by_city"), [
        f"{ct.index[-1]} was warmest ({ct['mean'].iloc[-1]:.1f} °C mean daily) and {ct.index[0]} coolest ({ct['mean'].iloc[0]:.1f} °C), a spread of {ct['mean'].iloc[-1] - ct['mean'].iloc[0]:.1f} °C.",
        f"Day-to-day variability (SD) was highest in {ct['std'].idxmax()} ({ct['std'].max():.1f} °C) and lowest in {ct['std'].idxmin()} ({ct['std'].min():.1f} °C).",
    ], ct.round(2)))

    tot = city_totals(d).sort_values()
    wdays = d.groupby("city")["wet_day"].sum().reindex(tot.index)
    fig, ax = plt.subplots()
    ax.barh(tot.index, tot.values, color="#2F6690")
    for i, (v, w) in enumerate(zip(tot.values, wdays.values)):
        ax.text(v, i, f" {w} wet days", va="center", fontsize=8)
    ax.set(title="Total rainfall by city", xlabel="mm")
    out.append(result("B9", "Rainfall by city", "Which cities receive the most rain?", _save(fig, "B9_rain_by_city"), [
        f"{tot.index[-1]} was wettest ({tot.iloc[-1]:.0f} mm, {wdays.iloc[-1]} wet days) and {tot.index[0]} driest ({tot.iloc[0]:.0f} mm, {wdays.iloc[0]} wet days): a ratio of {tot.iloc[-1] / tot.iloc[0]:.1f}×.",
    ], pd.DataFrame({"total_mm": tot.round(1), "wet_days": wdays})))

    pr = h.groupby("pressure_band", observed=True).agg(rain_prob=("is_rain_hour", "mean"), mean_precip=("precip_mm", "mean"), hours=("precip_mm", "size"))
    pr["rain_prob"] *= 100
    fig, ax = plt.subplots()
    pr["rain_prob"].plot.bar(ax=ax, color="#6C5B7B"); ax.set(title="Probability of rain by pressure band", xlabel="hPa", ylabel="% of hours with rain")
    out.append(result("B10", "Pressure vs rainfall", "Is low pressure a useful rain signal?", _save(fig, "B10_pressure_vs_rain"), [
        f"Rain fell in {pr['rain_prob'].iloc[0]:.1f}% of hours in the {pr.index[0]} hPa band versus {pr['rain_prob'].iloc[-1]:.1f}% at {pr.index[-1]} hPa.",
        f"Pressure vs hourly precipitation: Spearman ρ = {corr_pair(h, 'pressure_hpa', 'precip_mm')[1]:.2f}.",
    ], pr.round(3)))
    return out


# ================================================================ Multivariate
def multivariate(h: pd.DataFrame, d: pd.DataFrame) -> list[dict]:
    out = []
    months = month_order(h)
    cols = ["temp_c", "feels_like_c", "dew_point_c", "rh_pct", "precip_mm", "pressure_hpa", "cloud_pct", "wind_kmh", "gust_kmh", "sunshine_h"]
    cm = h[cols].corr(method="spearman")
    fig, ax = plt.subplots(figsize=(8, 6.5))
    im = ax.imshow(cm, cmap="RdBu_r", vmin=-1, vmax=1)
    ax.set_xticks(range(len(cols)), cols, rotation=45, ha="right"); ax.set_yticks(range(len(cols)), cols)
    for i in range(len(cols)):
        for j in range(len(cols)):
            ax.text(j, i, f"{cm.iat[i, j]:.2f}", ha="center", va="center", fontsize=7)
    fig.colorbar(im); ax.set_title("Spearman correlation matrix (hourly)"); ax.grid(False)
    trivial = {frozenset(p) for p in [("temp_c", "feels_like_c"), ("temp_c", "dew_point_c"), ("feels_like_c", "dew_point_c"), ("wind_kmh", "gust_kmh")]}
    pairs = cm.where(np.triu(np.ones(cm.shape, bool), 1)).stack().rename("rho").reset_index()
    pairs = pairs[~pairs.apply(lambda r: frozenset((r["level_0"], r["level_1"])) in trivial, axis=1)]
    pairs = pairs.reindex(pairs["rho"].abs().sort_values(ascending=False).index).head(6)
    out.append(result("M1", "Correlation matrix", "Which variables move together?", _save(fig, "M1_corr_matrix"), [
        "Strongest non-trivial associations (excluding derived pairs such as temperature/feels-like and wind/gust): " +
        "; ".join(f"{a} & {b} ρ={v:.2f}" for a, b, v in pairs.itertuples(index=False)) + ".",
    ], cm.round(3)))

    piv = h.pivot_table(index="city", columns="month_name", values="temp_c", aggfunc="mean")[months]
    piv = piv.loc[piv.mean(axis=1).sort_values(ascending=False).index]
    fig, ax = plt.subplots(figsize=(10, 5.5))
    im = ax.imshow(piv, cmap="RdYlBu_r", aspect="auto")
    ax.set_xticks(range(len(months)), months); ax.set_yticks(range(len(piv)), piv.index)
    for i in range(piv.shape[0]):
        for j in range(piv.shape[1]):
            ax.text(j, i, f"{piv.iat[i, j]:.1f}", ha="center", va="center", fontsize=7)
    fig.colorbar(im, label="°C"); ax.set_title("Mean temperature: city × month"); ax.grid(False)
    summer = [m for m in ["Jun", "Jul", "Aug"] if m in piv]; winter = [m for m in ["Dec", "Jan", "Feb"] if m in piv]
    s_rank, w_rank = piv[summer].mean(axis=1), piv[winter].mean(axis=1)
    out.append(result("M2", "City × month temperature", "Does the warmest city change by season?", _save(fig, "M2_city_month_temp"), [
        f"Warmest in summer (Jun–Aug): {s_rank.idxmax()} ({s_rank.max():.1f} °C); warmest in winter (Dec–Feb): {w_rank.idxmax()} ({w_rank.max():.1f} °C).",
        f"Seasonal amplitude (summer − winter) was largest in {(s_rank - w_rank).idxmax()} ({(s_rank - w_rank).max():.1f} °C) and smallest in {(s_rank - w_rank).idxmin()} ({(s_rank - w_rank).min():.1f} °C).",
    ], piv.round(2)))

    rp = d.groupby(["city", "month_name"])["precip_sum"].sum().unstack()[months]
    rp = rp.loc[rp.sum(axis=1).sort_values(ascending=False).index]
    fig, ax = plt.subplots(figsize=(10, 5.5))
    im = ax.imshow(rp, cmap="Blues", aspect="auto")
    ax.set_xticks(range(len(months)), months); ax.set_yticks(range(len(rp)), rp.index)
    for i in range(rp.shape[0]):
        for j in range(rp.shape[1]):
            ax.text(j, i, f"{rp.iat[i, j]:.0f}", ha="center", va="center", fontsize=7)
    fig.colorbar(im, label="mm"); ax.set_title("Rainfall total: city × month"); ax.grid(False)
    peak = rp.idxmax(axis=1)
    out.append(result("M3", "City × month rainfall", "Do all cities share the same wet season?", _save(fig, "M3_city_month_rain"), [
        f"Single wettest city-month: {rp.stack().idxmax()[0]} in {rp.stack().idxmax()[1]} ({rp.stack().max():.0f} mm).",
        "Each city's wettest month: " + ", ".join(f"{c} {m}" for c, m in peak.items()) + ".",
    ], rp.round(1)))

    hm = h.pivot_table(index="hour", columns="month_name", values="temp_c", aggfunc="mean")[months]
    amp = hm.max() - hm.min()
    fig, ax = plt.subplots(figsize=(10, 5.5))
    im = ax.imshow(hm, cmap="RdYlBu_r", aspect="auto", origin="lower")
    ax.set_xticks(range(len(months)), months); ax.set_yticks(range(0, 24, 3), range(0, 24, 3)); ax.set_ylabel("Local hour")
    fig.colorbar(im, label="°C"); ax.set_title("Mean temperature: hour × month (all cities)"); ax.grid(False)
    out.append(result("M4", "Hour × month temperature", "How does the daily cycle change through the year?", _save(fig, "M4_hour_month_temp"), [
        f"The diurnal amplitude was largest in {amp.idxmax()} ({amp.max():.1f} °C) and smallest in {amp.idxmin()} ({amp.min():.1f} °C).",
    ], amp.round(2).to_frame("diurnal_amplitude_c")))

    smp = h.dropna(subset=["temp_c", "rh_pct"]).sample(min(20000, len(h)), random_state=42)
    fig, ax = plt.subplots()
    for s, c in SEASON_COLORS.items():
        sub = smp[smp["season"] == s]
        ax.scatter(sub["temp_c"], sub["rh_pct"], s=3, alpha=.3, color=c, label=s)
    ax.legend(markerscale=4); ax.set(title="Temperature vs humidity by season (20k-hour sample)", xlabel="°C", ylabel="RH %")
    sc = h.groupby("season", observed=True)[["temp_c", "rh_pct"]].apply(lambda g: g["temp_c"].corr(g["rh_pct"])).rename("pearson_r")
    out.append(result("M5", "Temperature–humidity by season", "Is the temperature–humidity link the same all year?", _save(fig, "M5_temp_rh_season"), [
        "Within-season Pearson r: " + ", ".join(f"{k} {v:.2f}" for k, v in sc.items()) + ".",
        f"The relationship was strongest in {sc.abs().idxmax()} and weakest in {sc.abs().idxmin()}.",
    ], sc.round(3).to_frame()))

    wb = pd.cut(h["wind_kmh"], [-1, 10, 20, 30, 40, 300], labels=["0-10", "10-20", "20-30", "30-40", "40+"])
    grid = h.assign(wb=wb).pivot_table(index="pressure_band", columns="wb", values="is_rain_hour", aggfunc="mean", observed=True) * 100
    counts = h.assign(wb=wb).pivot_table(index="pressure_band", columns="wb", values="is_rain_hour", aggfunc="size", observed=True)
    grid = grid.where(counts >= 30)
    fig, ax = plt.subplots()
    im = ax.imshow(grid, cmap="GnBu", aspect="auto", origin="lower")
    ax.set_xticks(range(grid.shape[1]), grid.columns); ax.set_yticks(range(grid.shape[0]), grid.index)
    ax.set(xlabel="Wind km/h", ylabel="Pressure hPa", title="% of hours with rain: pressure × wind (cells ≥30 h)")
    for i in range(grid.shape[0]):
        for j in range(grid.shape[1]):
            if pd.notna(grid.iat[i, j]):
                ax.text(j, i, f"{grid.iat[i, j]:.0f}", ha="center", va="center", fontsize=8)
    fig.colorbar(im); ax.grid(False)
    best = grid.stack().idxmax(); worst = grid.stack().idxmin()
    out.append(result("M6", "Pressure × wind → rain", "Do low pressure and strong wind combine to raise rain risk?", _save(fig, "M6_pressure_wind_rain"), [
        f"Rain probability was highest ({grid.stack().max():.0f}%) with pressure {best[0]} hPa and wind {best[1]} km/h, and lowest ({grid.stack().min():.0f}%) at {worst[0]} hPa with wind {worst[1]} km/h.",
    ], grid.round(1)))

    sw = h.pivot_table(index="city", columns="season", values="wind_kmh", aggfunc="mean", observed=True)
    sw = sw.loc[sw.mean(axis=1).sort_values(ascending=False).index]
    fig, ax = plt.subplots()
    im = ax.imshow(sw, cmap="Purples", aspect="auto")
    ax.set_xticks(range(sw.shape[1]), sw.columns); ax.set_yticks(range(len(sw)), sw.index)
    for i in range(sw.shape[0]):
        for j in range(sw.shape[1]):
            ax.text(j, i, f"{sw.iat[i, j]:.1f}", ha="center", va="center", fontsize=8)
    fig.colorbar(im, label="km/h"); ax.set_title("Mean wind speed: city × season"); ax.grid(False)
    sm = sw.mean()
    out.append(result("M7", "City × season wind", "Where and when is it windiest?", _save(fig, "M7_city_season_wind"), [
        f"Windiest city overall: {sw.index[0]} ({sw.iloc[0].mean():.1f} km/h); calmest: {sw.index[-1]} ({sw.iloc[-1].mean():.1f} km/h).",
        f"Windiest season across cities: {sm.idxmax()} ({sm.max():.1f} km/h); calmest: {sm.idxmin()} ({sm.min():.1f} km/h).",
    ], sw.round(2)))

    ca = h.groupby(["season", "day_night", "cloud_band"], observed=True)["temp_anomaly_c"].mean().unstack("cloud_band")
    fig, ax = plt.subplots(figsize=(10, 4.8))
    ca.plot.bar(ax=ax, color=["#D1A01F", "#8D99AE", "#4A5568"]); ax.axhline(0, color="k", lw=.8)
    ax.set(title="Temperature anomaly by cloud cover, split by season and day/night", ylabel="°C vs city-month-hour mean", xlabel="")
    plt.setp(ax.get_xticklabels(), rotation=30, ha="right")
    f = []
    for (season, dn) in [("Winter", "Night"), ("Summer", "Day")]:
        if (season, dn) in ca.index and {"Clear (<20%)", "Overcast (>70%)"} <= set(ca.columns):
            row = ca.loc[(season, dn)]
            f.append(f"{season} {dn.lower()}s: clear hours averaged {row['Clear (<20%)']:+.1f} °C and overcast hours {row['Overcast (>70%)']:+.1f} °C relative to normal for that city, month and hour.")
    out.append(result("M8", "Cloud × season × day/night", "Does cloud warm or cool, depending on time of day and year?", _save(fig, "M8_cloud_season_daynight"), f, ca.round(2)))

    cs = h.groupby("city").agg(lat=("lat", "first"), lon=("lon", "first"), temp=("temp_c", "mean"), elev=("grid_elevation_m", "first"))
    cs["rain"] = city_totals(d)
    fig, ax = plt.subplots(figsize=(6.5, 7))
    sc_ = ax.scatter(cs["lon"], cs["lat"], s=cs["rain"] / cs["rain"].max() * 900, c=cs["temp"], cmap="RdYlBu_r", edgecolor="k", alpha=.85)
    for c, r_ in cs.iterrows():
        ax.annotate(c, (r_["lon"], r_["lat"]), xytext=(6, 4), textcoords="offset points", fontsize=8)
    fig.colorbar(sc_, label="Mean °C"); ax.set(title="Cities: location, temperature (colour), rainfall (size)", xlabel="Longitude", ylabel="Latitude")
    out.append(result("M9", "Geography vs climate", "Do latitude and longitude explain city differences?", _save(fig, "M9_geography_bubble"), [
        f"Across {len(cs)} cities, latitude vs mean temperature r = {cs['lat'].corr(cs['temp']):.2f}; longitude vs total rainfall r = {cs['lon'].corr(cs['rain']):.2f} (negative = wetter further west).",
        (f"Grid-cell elevation vs mean temperature r = {cs['elev'].corr(cs['temp']):.2f}." if cs["elev"].nunique() > 1 else "Grid-cell elevation is identical across cities, so its correlation cannot be computed.")
        + f" With n = {len(cs)} cities these are descriptive, not statistically robust.",
    ], cs.round(2)))

    feats = ["rh_mean", "pressure_mean", "wind_mean", "cloud_mean", "temp_mean"]
    md = d.dropna(subset=feats + ["precip_sum"])
    X = (md[feats] - md[feats].mean()) / md[feats].std()
    X1 = np.column_stack([np.ones(len(X)), X.values]); y = md["precip_sum"].values
    beta, *_ = np.linalg.lstsq(X1, y, rcond=None)
    r2 = 1 - ((y - X1 @ beta) ** 2).sum() / ((y - y.mean()) ** 2).sum()
    coefs = pd.Series(beta[1:], index=feats).sort_values()
    fig, ax = plt.subplots()
    coefs.plot.barh(ax=ax, color=np.where(coefs > 0, "#2F6690", "#B3541E"))
    ax.set(title=f"Daily rainfall ~ standardised predictors (OLS, R² = {r2:.2f})", xlabel="mm change per +1 SD")
    out.append(result("M10", "Multiple regression: drivers of daily rainfall", "Holding other factors fixed, which conditions go with wetter days?", _save(fig, "M10_rain_regression"), [
        f"An OLS model on {len(md):,} city-days explains R² = {r2:.2f} of the variance in daily rainfall.",
        "Standardised coefficients (mm per 1 SD): " + ", ".join(f"{k} {v:+.2f}" for k, v in coefs.sort_values(key=abs, ascending=False).items()) + ".",
        "This is descriptive association, not causation; rainfall is zero-inflated, so a linear model is only a first approximation.",
    ], coefs.round(3).to_frame("std_coef_mm")))
    return out


# ================================================================ Time series
def time_series(h: pd.DataFrame, d: pd.DataFrame, focus_city: str | None = None) -> list[dict]:
    out = []
    net = d.groupby("date").agg(temp=("temp_mean", "mean"), rain=("precip_sum", "mean")).asfreq("D")
    net["r7"] = net["temp"].rolling(7, min_periods=5).mean()
    net["r30"] = net["temp"].rolling(30, min_periods=21).mean()
    fig, ax = plt.subplots(figsize=(11, 4.8))
    ax.plot(net.index, net["temp"], color="#BBBBBB", lw=.8, label="Daily")
    ax.plot(net.index, net["r7"], color=MAIN, lw=1.5, label="7-day mean")
    ax.plot(net.index, net["r30"], color="#B3541E", lw=2, label="30-day mean")
    ax.set(title="All-city daily mean temperature with rolling averages", ylabel="°C"); ax.legend()
    w7, c7 = net["r7"].idxmax(), net["r7"].idxmin()
    out.append(result("T1", "Daily temperature with 7/30-day rolling means", "How did temperature evolve over the period?", _save(fig, "T1_daily_temp_rolling"), [
        f"The warmest 7-day spell ended {fmt_date(w7)} ({net['r7'].max():.1f} °C) and the coldest ended {fmt_date(c7)} ({net['r7'].min():.1f} °C).",
        f"The 30-day mean ranged from {net['r30'].min():.1f} to {net['r30'].max():.1f} °C.",
    ]))

    focus = focus_city if focus_city in set(h["city"]) else h["city"].iloc[0]
    fh = h[h["city"] == focus].set_index("time_local")
    last = fh[fh.index >= fh.index.max() - pd.Timedelta(days=30)]
    fig, ax = plt.subplots(figsize=(11, 4.8))
    ax.plot(last.index, last["temp_c"], color="#BBBBBB", lw=.8, label="Hourly")
    ax.plot(last.index, last["temp_c_roll24h"], color=MAIN, label="24-hour mean")
    ax.plot(last.index, last["temp_c_roll168h"], color="#B3541E", lw=2, label="7-day (168 h) mean")
    ax.set(title=f"{focus}: last 30 days of hourly temperature", ylabel="°C"); ax.legend()
    out.append(result("T2", f"Hourly rolling averages ({focus})", "How do hourly, daily and weekly smoothing compare?", _save(fig, "T2_hourly_rolling_focus"), [
        f"Over the final 30 days in {focus}, hourly temperature ranged {last['temp_c'].min():.1f}–{last['temp_c'].max():.1f} °C while the 168-hour mean stayed within {last['temp_c_roll168h'].min():.1f}–{last['temp_c_roll168h'].max():.1f} °C.",
    ]))

    wk = d.set_index("date").groupby("city")["precip_sum"].resample("W-MON").sum().unstack(0)
    netwk = wk.mean(axis=1)
    fig, ax = plt.subplots(figsize=(11, 4.8))
    ax.bar(netwk.index, netwk.values, width=5, color="#2F6690")
    ax.set(title="Weekly rainfall (mean across cities)", ylabel="mm per week")
    out.append(result("T3", "Weekly rainfall", "Which weeks were wettest?", _save(fig, "T3_weekly_rain"), [
        f"The wettest week (ending {fmt_date(netwk.idxmax())}) averaged {netwk.max():.1f} mm per city; {int((netwk < 1).sum())} weeks averaged under 1 mm.",
        f"Wettest single city-week: {wk.stack().idxmax()[1]} week ending {fmt_date(wk.stack().idxmax()[0])} with {wk.stack().max():.1f} mm.",
    ], wk.round(1)))

    mo = d.groupby("year_month").agg(temp=("temp_mean", "mean"), rain=("precip_sum", "sum"))
    mo["rain"] = mo["rain"] / d["city"].nunique()
    mo["temp_anom"] = mo["temp"] - mo["temp"].mean()
    fig, ax = plt.subplots(figsize=(11, 4.8))
    ax.bar(mo.index, mo["temp_anom"], color=np.where(mo["temp_anom"] > 0, "#B3541E", MAIN))
    ax.set(title="Monthly mean temperature relative to period mean", ylabel="°C"); plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    out.append(result("T4", "Monthly temperature anomaly", "Which months were relatively warm or cold?", _save(fig, "T4_monthly_anomaly"), [
        f"Relative to the period mean of {mo['temp'].mean():.1f} °C, {mo['temp_anom'].idxmax()} was the warmest month ({mo['temp_anom'].max():+.1f} °C) and {mo['temp_anom'].idxmin()} the coldest ({mo['temp_anom'].min():+.1f} °C).",
        "Note: with one year of data, this anomaly is versus the period itself, not a 30-year climate normal.",
    ], mo.round(2)))

    hs = h.groupby("time_utc")["temp_c"].mean()
    lags = list(range(1, 337))
    ac = pd.Series([hs.autocorr(l) for l in lags], index=lags)
    fig, ax = plt.subplots()
    ax.plot(ac.index, ac.values, color=MAIN)
    for l in (24, 168):
        ax.axvline(l, color="#B3541E", ls=":"); ax.text(l, ac.min(), f" {l} h", color="#B3541E")
    ax.set(title="Autocorrelation of all-city hourly temperature", xlabel="Lag (hours)", ylabel="r")
    anom = h.groupby("time_utc")["temp_anomaly_c"].mean()
    out.append(result("T5", "Temperature autocorrelation (persistence)", "How predictable is temperature from its own past?", _save(fig, "T5_autocorrelation"), [
        f"Autocorrelation is {ac[1]:.3f} at 1 h, {ac[24]:.3f} at 24 h and {ac[168]:.3f} at 168 h.",
        f"After removing the seasonal and daily cycle, anomaly autocorrelation is {anom.autocorr(24):.2f} at 24 h ({strength(anom.autocorr(24))}) and {anom.autocorr(168):.2f} at 7 days ({strength(anom.autocorr(168))}): this measures how far today's departure from normal carries into tomorrow and next week.",
    ], ac.loc[[1, 3, 6, 12, 24, 48, 72, 168, 336]].round(3).to_frame("autocorr")))

    net["rain30"] = net["rain"].rolling(30, min_periods=21).sum()
    fig, ax = plt.subplots(figsize=(11, 4.8))
    ax.fill_between(net.index, net["rain30"], color="#9CC3DE"); ax.set(title="30-day rolling rainfall (mean across cities)", ylabel="mm per 30 days")
    dry = d.assign(dry=~d["wet_day"]).sort_values(["city", "date"])
    runs = dry.groupby("city")["dry"].apply(lambda s: s.groupby((~s).cumsum()).sum().max())
    out.append(result("T6", "Rolling rainfall and dry spells", "When were the wettest and driest periods?", _save(fig, "T6_rain_rolling_dryspells"), [
        f"The 30-day rolling total peaked at {net['rain30'].max():.0f} mm (window ending {fmt_date(net['rain30'].idxmax())}) and fell to {net['rain30'].min():.0f} mm (ending {fmt_date(net['rain30'].idxmin())}).",
        f"Longest run of consecutive dry days (<1 mm): {runs.idxmax()} with {int(runs.max())} days; shortest maximum run: {runs.idxmin()} ({int(runs.min())} days).",
    ], runs.rename("longest_dry_run_days").to_frame()))
    return out


# ================================================================ Extremes
def extremes(h: pd.DataFrame, d: pd.DataFrame) -> dict:
    cols = ["city", "time_local", "temp_c", "precip_mm", "gust_kmh", "pressure_hpa", "condition"]
    tables = {
        "hottest_hours": h.nlargest(10, "temp_c")[cols],
        "coldest_hours": h.nsmallest(10, "temp_c")[cols],
        "wettest_hours": h.nlargest(10, "precip_mm")[cols],
        "strongest_gusts": h.nlargest(10, "gust_kmh")[cols],
        "lowest_pressure": h.nsmallest(10, "pressure_hpa")[cols],
    }
    counts = d.groupby("city")[["frost_day", "summer_day", "hot_day", "wet_day", "heavy_rain_day", "gale_gust_day"]].sum().astype(int)
    thresholds = h.groupby("city").agg(
        temp_p01=("temp_c", lambda s: s.quantile(.01)), temp_p99=("temp_c", lambda s: s.quantile(.99)),
        rain_rate_p99=("precip_mm", lambda s: s[s > 0].quantile(.99)), gust_p99=("gust_kmh", lambda s: s.quantile(.99)),
        pressure_p01=("pressure_hpa", lambda s: s.quantile(.01)))
    fig, ax = plt.subplots(figsize=(10, 5))
    counts[["frost_day", "summer_day", "heavy_rain_day", "gale_gust_day"]].plot.bar(ax=ax, color=["#88CCEE", "#D1A01F", "#2F6690", "#6C5B7B"])
    ax.set(title="Extreme-day counts by city", ylabel="Days"); plt.setp(ax.get_xticklabels(), rotation=35, ha="right")
    findings = [
        f"Most frost days: {counts['frost_day'].idxmax()} ({counts['frost_day'].max()}); fewest: {counts['frost_day'].idxmin()} ({counts['frost_day'].min()}).",
        f"Most summer days (≥{config.SUMMER_DAY_C:.0f} °C): {counts['summer_day'].idxmax()} ({counts['summer_day'].max()}); hot days ≥{config.HOT_DAY_C:.0f} °C across all cities: {counts['hot_day'].sum()}.",
        f"Most gale-force-gust days (≥{config.GALE_GUST_KMH:.0f} km/h): {counts['gale_gust_day'].idxmax()} ({counts['gale_gust_day'].max()}).",
        f"Most heavy-rain days (≥{config.HEAVY_RAIN_DAY_MM:.0f} mm): {counts['heavy_rain_day'].idxmax()} ({counts['heavy_rain_day'].max()}).",
        f"Strongest gust: {tables['strongest_gusts'].iloc[0]['gust_kmh']:.0f} km/h in {tables['strongest_gusts'].iloc[0]['city']} at {fmt_time(tables['strongest_gusts'].iloc[0]['time_local'])}; heaviest hourly rain: {tables['wettest_hours'].iloc[0]['precip_mm']:.1f} mm in {tables['wettest_hours'].iloc[0]['city']} at {fmt_time(tables['wettest_hours'].iloc[0]['time_local'])}.",
    ]
    return {"tables": tables, "counts": counts, "thresholds": thresholds.round(1),
            "figure": _save(fig, "X1_extreme_day_counts"), "findings": findings}


# ================================================================ City comparison
def city_comparison(h: pd.DataFrame, d: pd.DataFrame) -> dict:
    t = h.groupby("city").agg(nation=("nation", "first"), mean_temp_c=("temp_c", "mean"), mean_rh_pct=("rh_pct", "mean"),
                              mean_wind_kmh=("wind_kmh", "mean"), max_gust_kmh=("gust_kmh", "max"),
                              mean_pressure_hpa=("pressure_hpa", "mean"), mean_cloud_pct=("cloud_pct", "mean"),
                              rain_hours_pct=("is_rain_hour", "mean"))
    t["rain_hours_pct"] *= 100
    dd = d.groupby("city").agg(mean_daily_max_c=("temp_max", "mean"), mean_daily_min_c=("temp_min", "mean"),
                               total_rain_mm=("precip_sum", "sum"), wet_days=("wet_day", "sum"),
                               sunshine_h=("sunshine_h", "sum"), frost_days=("frost_day", "sum"))
    t = t.join(dd)
    num = t.drop(columns="nation")
    z = (num - num.mean()) / num.std()
    fig, ax = plt.subplots(figsize=(11, 5.5))
    im = ax.imshow(z, cmap="RdBu_r", vmin=-2.5, vmax=2.5, aspect="auto")
    ax.set_xticks(range(z.shape[1]), z.columns, rotation=40, ha="right"); ax.set_yticks(range(len(z)), z.index)
    fig.colorbar(im, label="z-score vs other cities"); ax.set_title("City profile (standardised)"); ax.grid(False)
    nat = t.groupby("nation")[["mean_temp_c", "total_rain_mm", "mean_wind_kmh"]].mean()
    findings = [
        f"Sunniest city: {t['sunshine_h'].idxmax()} ({t['sunshine_h'].max():.0f} h); dullest: {t['sunshine_h'].idxmin()} ({t['sunshine_h'].min():.0f} h).",
        f"Highest share of rain hours: {t['rain_hours_pct'].idxmax()} ({t['rain_hours_pct'].max():.1f}%); lowest: {t['rain_hours_pct'].idxmin()} ({t['rain_hours_pct'].min():.1f}%).",
        f"Most humid: {t['mean_rh_pct'].idxmax()} ({t['mean_rh_pct'].max():.1f}%); least humid: {t['mean_rh_pct'].idxmin()} ({t['mean_rh_pct'].min():.1f}%).",
        "By nation (city averages): " + "; ".join(f"{n} {r.mean_temp_c:.1f} °C, {r.total_rain_mm:.0f} mm, {r.mean_wind_kmh:.1f} km/h" for n, r in nat.iterrows()) + ".",
    ]
    seasonal = h.pivot_table(index="city", columns="season", values="temp_c", aggfunc="mean", observed=True)
    return {"table": t.round(1), "ranks": num.rank(ascending=False).astype(int), "seasonal_temp": seasonal.round(1),
            "figure": _save(fig, "C1_city_profile_heatmap"), "findings": findings}
