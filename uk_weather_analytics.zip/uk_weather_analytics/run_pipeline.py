"""End-to-end pipeline:
API -> JSON -> Pandas -> quality -> cleaning -> features -> KPIs -> EDA -> time series -> report.

Usage:
    python run_pipeline.py                      # last 366 days ending 7 days ago, all cities
    python run_pipeline.py --start 2025-01-01 --end 2025-12-31
    python run_pipeline.py --cities London Glasgow Cardiff --refresh
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from datetime import date

import config
from src import analysis, api_client, processing, report

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", datefmt="%H:%M:%S")
log = logging.getLogger("pipeline")


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--start", type=date.fromisoformat, default=config.DEFAULT_START)
    p.add_argument("--end", type=date.fromisoformat, default=config.DEFAULT_END)
    p.add_argument("--cities", nargs="+", default=list(config.CITIES), choices=list(config.CITIES))
    p.add_argument("--refresh", action="store_true", help="ignore cached JSON and re-download")
    p.add_argument("--focus-city", default="London", help="city used for the hourly rolling-average chart")
    return p.parse_args()


def main():
    a = parse_args()
    if (a.end - a.start).days < 364:
        log.warning("Window is shorter than 12 months (%s to %s); the brief requires at least 12 months.", a.start, a.end)
    for p in (config.RAW_DIR, config.PROCESSED_DIR, config.FIG_DIR, config.TABLE_DIR):
        p.mkdir(parents=True, exist_ok=True)

    log.info("1/7 Extracting historical data %s -> %s for %d cities", a.start, a.end, len(a.cities))
    payloads, failures = api_client.fetch_historical_all(a.cities, a.start, a.end, force=a.refresh)
    if not payloads:
        sys.exit(f"No data downloaded. Errors: {failures}")
    units = processing.units_from_payload(next(iter(payloads.values())))

    log.info("2/7 JSON -> Pandas")
    raw = processing.payloads_to_frame(payloads)
    log.info("Raw dtypes:\n%s", raw.dtypes.to_string())
    log.info("Raw head:\n%s", raw.head().to_string())

    log.info("3/7 Data quality assessment")
    quality = processing.quality_assessment(raw, a.start, a.end)
    log.info("\n%s", quality["summary"].to_string())

    log.info("4/7 Cleaning + feature engineering")
    clean, cleaning_log = processing.clean(raw)
    hourly = processing.add_features(clean)
    daily_all = processing.daily_aggregate(hourly)
    daily = daily_all[daily_all["is_full_day"]].copy()
    hourly.to_parquet(config.PROCESSED_DIR / "hourly.parquet", index=False)
    daily_all.to_parquet(config.PROCESSED_DIR / "daily.parquet", index=False)
    (config.PROCESSED_DIR / "meta.json").write_text(json.dumps(
        {"start": str(a.start), "end": str(a.end), "cities": sorted(payloads), "failures": failures, "units": units,
         "cleaning_log": cleaning_log}, indent=2, default=str))

    log.info("5/7 KPIs, univariate, bivariate, multivariate")
    kpis = analysis.compute_kpis(hourly, daily)
    log.info("\n%s", kpis.to_string(index=False))
    results = {"univariate": analysis.univariate(hourly, daily),
               "bivariate": analysis.bivariate(hourly, daily),
               "multivariate": analysis.multivariate(hourly, daily)}

    log.info("6/7 Time series, extremes, city comparison")
    results["time_series"] = analysis.time_series(hourly, daily, a.focus_city)
    ext = analysis.extremes(hourly, daily)
    cities = analysis.city_comparison(hourly, daily)

    kpis.to_csv(config.TABLE_DIR / "kpis.csv", index=False)
    cities["table"].to_csv(config.TABLE_DIR / "city_comparison.csv")
    ext["counts"].to_csv(config.TABLE_DIR / "extreme_day_counts.csv")
    ext["thresholds"].to_csv(config.TABLE_DIR / "alert_thresholds.csv")
    quality["summary"].to_csv(config.TABLE_DIR / "data_quality_summary.csv")
    for group in results.values():
        for r in group:
            if r["table"] is not None:
                r["table"].to_csv(config.TABLE_DIR / f"{r['id']}.csv")

    log.info("7/7 Writing report")
    report.write_report(start=a.start, end=a.end, h=hourly, d=daily, units=units, quality=quality,
                        cleaning_log=cleaning_log, kpis=kpis, results=results, ext=ext, cities=cities, failures=failures)
    log.info("Done. Report: %s | Dashboard: streamlit run app.py", config.OUTPUT_DIR / "report.md")


if __name__ == "__main__":
    main()
