"""Project configuration for the Live UK Weather Analytics project.

Everything that controls *what* is fetched and *how* it is interpreted lives here,
so the pipeline and the dashboard always agree on definitions.
"""
from datetime import date, timedelta
from pathlib import Path

# ---------------------------------------------------------------- paths
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
RAW_DIR = DATA_DIR / "raw"              # untouched JSON responses from the API
PROCESSED_DIR = DATA_DIR / "processed"  # cleaned + feature-engineered tables
OUTPUT_DIR = BASE_DIR / "outputs"
FIG_DIR = OUTPUT_DIR / "figures"
TABLE_DIR = OUTPUT_DIR / "tables"

# ---------------------------------------------------------------- API endpoints
ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"   # historical (ERA5-based)
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"        # live / current conditions

# The archive lags real time by several days. The default window is the 12 most recent
# COMPLETE calendar months available, so no month is partially sampled (which would
# bias monthly totals). Override with --start/--end in run_pipeline.py.
ARCHIVE_LAG_DAYS = 7
HISTORY_MONTHS = 12


def _default_window(today: date | None = None) -> tuple[date, date]:
    latest = (today or date.today()) - timedelta(days=ARCHIVE_LAG_DAYS)
    end = latest if (latest + timedelta(days=1)).day == 1 else latest.replace(day=1) - timedelta(days=1)
    y, m = end.year, end.month - (HISTORY_MONTHS - 1)
    while m <= 0:
        y, m = y - 1, m + 12
    return date(y, m, 1), end


DEFAULT_START, DEFAULT_END = _default_window()

LOCAL_TZ = "Europe/London"

# ---------------------------------------------------------------- geography
CITIES = {
    "London":     {"lat": 51.5074, "lon": -0.1278, "nation": "England"},
    "Birmingham": {"lat": 52.4862, "lon": -1.8904, "nation": "England"},
    "Manchester": {"lat": 53.4808, "lon": -2.2426, "nation": "England"},
    "Leeds":      {"lat": 53.8008, "lon": -1.5491, "nation": "England"},
    "Newcastle":  {"lat": 54.9783, "lon": -1.6178, "nation": "England"},
    "Bristol":    {"lat": 51.4545, "lon": -2.5879, "nation": "England"},
    "Plymouth":   {"lat": 50.3755, "lon": -4.1427, "nation": "England"},
    "Cardiff":    {"lat": 51.4816, "lon": -3.1791, "nation": "Wales"},
    "Glasgow":    {"lat": 55.8642, "lon": -4.2518, "nation": "Scotland"},
    "Edinburgh":  {"lat": 55.9533, "lon": -3.1883, "nation": "Scotland"},
    "Aberdeen":   {"lat": 57.1497, "lon": -2.0943, "nation": "Scotland"},
    "Belfast":    {"lat": 54.5973, "lon": -5.9301, "nation": "Northern Ireland"},
}

# ---------------------------------------------------------------- variables
HOURLY_VARS = [
    "temperature_2m", "relative_humidity_2m", "dew_point_2m", "apparent_temperature",
    "precipitation", "rain", "snowfall", "weather_code",
    "pressure_msl", "surface_pressure", "cloud_cover",
    "wind_speed_10m", "wind_direction_10m", "wind_gusts_10m",
    "is_day", "sunshine_duration",
]

CURRENT_VARS = [
    "temperature_2m", "relative_humidity_2m", "apparent_temperature", "is_day",
    "precipitation", "rain", "weather_code", "cloud_cover", "pressure_msl",
    "wind_speed_10m", "wind_direction_10m", "wind_gusts_10m",
]

LIVE_HOURLY_VARS = [
    "temperature_2m", "relative_humidity_2m", "precipitation",
    "wind_speed_10m", "wind_gusts_10m", "pressure_msl", "cloud_cover",
]

# Short, readable column names used everywhere after ingestion.
RENAME = {
    "temperature_2m": "temp_c",
    "relative_humidity_2m": "rh_pct",
    "dew_point_2m": "dew_point_c",
    "apparent_temperature": "feels_like_c",
    "precipitation": "precip_mm",
    "rain": "rain_mm",
    "snowfall": "snow_cm",
    "weather_code": "weather_code",
    "pressure_msl": "pressure_hpa",
    "surface_pressure": "surface_pressure_hpa",
    "cloud_cover": "cloud_pct",
    "wind_speed_10m": "wind_kmh",
    "wind_direction_10m": "wind_dir_deg",
    "wind_gusts_10m": "gust_kmh",
    "is_day": "is_day",
    "sunshine_duration": "sunshine_s",
}

# Physically plausible ranges for the UK. Values outside are treated as invalid.
VALID_RANGES = {
    "temp_c": (-30, 45),
    "feels_like_c": (-45, 50),
    "dew_point_c": (-40, 35),
    "rh_pct": (0, 100),
    "precip_mm": (0, 150),
    "rain_mm": (0, 150),
    "snow_cm": (0, 100),
    "pressure_hpa": (920, 1070),
    "surface_pressure_hpa": (850, 1070),
    "cloud_pct": (0, 100),
    "wind_kmh": (0, 250),
    "gust_kmh": (0, 300),
    "wind_dir_deg": (0, 360),
    "sunshine_s": (0, 3600),
}

CONTINUOUS_VARS = ["temp_c", "feels_like_c", "dew_point_c", "rh_pct", "pressure_hpa",
                   "surface_pressure_hpa", "cloud_pct", "wind_kmh", "gust_kmh"]
ACCUMULATED_VARS = ["precip_mm", "rain_mm", "snow_cm", "sunshine_s"]
MAX_INTERPOLATION_HOURS = 3

# ---------------------------------------------------------------- definitions / thresholds
RAIN_HOUR_MM = 0.1        # an hour "with rain"
HEAVY_RAIN_HOUR_MM = 4.0  # Met Office description of heavy rain rate (mm/h)
WET_DAY_MM = 1.0          # standard climatological "wet day" (>= 1 mm)
HEAVY_RAIN_DAY_MM = 10.0
FROST_C = 0.0
SUMMER_DAY_C = 25.0
HOT_DAY_C = 30.0
GALE_GUST_KMH = 62.0      # gusts at/above Beaufort 8 wind speed
MIN_HOURS_FOR_FULL_DAY = 20

SEASONS = {12: "Winter", 1: "Winter", 2: "Winter", 3: "Spring", 4: "Spring", 5: "Spring",
           6: "Summer", 7: "Summer", 8: "Summer", 9: "Autumn", 10: "Autumn", 11: "Autumn"}
SEASON_ORDER = ["Winter", "Spring", "Summer", "Autumn"]

# WMO weather interpretation codes used by Open-Meteo -> (description, group)
WMO_CODES = {
    0: ("Clear sky", "Clear"), 1: ("Mainly clear", "Clear"),
    2: ("Partly cloudy", "Cloudy"), 3: ("Overcast", "Cloudy"),
    45: ("Fog", "Fog"), 48: ("Depositing rime fog", "Fog"),
    51: ("Light drizzle", "Drizzle"), 53: ("Moderate drizzle", "Drizzle"),
    55: ("Dense drizzle", "Drizzle"), 56: ("Light freezing drizzle", "Drizzle"),
    57: ("Dense freezing drizzle", "Drizzle"),
    61: ("Slight rain", "Rain"), 63: ("Moderate rain", "Rain"), 65: ("Heavy rain", "Rain"),
    66: ("Light freezing rain", "Rain"), 67: ("Heavy freezing rain", "Rain"),
    71: ("Slight snow", "Snow"), 73: ("Moderate snow", "Snow"), 75: ("Heavy snow", "Snow"),
    77: ("Snow grains", "Snow"),
    80: ("Slight rain showers", "Showers"), 81: ("Moderate rain showers", "Showers"),
    82: ("Violent rain showers", "Showers"),
    85: ("Slight snow showers", "Snow"), 86: ("Heavy snow showers", "Snow"),
    95: ("Thunderstorm", "Thunderstorm"), 96: ("Thunderstorm with slight hail", "Thunderstorm"),
    99: ("Thunderstorm with heavy hail", "Thunderstorm"),
}

# Beaufort scale upper bounds in km/h
BEAUFORT = [(1, 0, "Calm"), (5, 1, "Light air"), (11, 2, "Light breeze"), (19, 3, "Gentle breeze"),
            (28, 4, "Moderate breeze"), (38, 5, "Fresh breeze"), (49, 6, "Strong breeze"),
            (61, 7, "Near gale"), (74, 8, "Gale"), (88, 9, "Strong gale"),
            (102, 10, "Storm"), (117, 11, "Violent storm"), (float("inf"), 12, "Hurricane force")]

LIVE_REFRESH_SECONDS = 600  # Open-Meteo "current" values update every 15 minutes
