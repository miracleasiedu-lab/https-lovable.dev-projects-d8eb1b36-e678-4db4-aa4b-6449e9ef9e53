# Live UK Weather Analytics Dashboard

An analytics project for an environmental monitoring and operations team. It combines 12 months of hourly historical weather with live conditions from the free [Open-Meteo](https://open-meteo.com) API for 12 UK cities, then delivers a generated analysis report and an auto-refreshing Streamlit dashboard.

Every number in the report and the dashboard is calculated at run time from the API data. The insight, recommendation and conclusion sentences are templates filled in with computed values. Where a sentence makes an interpretive claim, such as "pressure is a useful rain signal", the code only says it if the computed numbers support it.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python run_pipeline.py        # fetch history, clean, analyse; writes outputs/report.md (about 2–4 min on first run)
streamlit run app.py          # dashboard at http://localhost:8501
```

No API key is needed. The dashboard can also download the history itself if you launch it first.

Useful options:

```bash
python run_pipeline.py --start 2025-01-01 --end 2025-12-31     # explicit window
python run_pipeline.py --cities London Glasgow Cardiff Belfast   # subset of cities
python run_pipeline.py --refresh                                 # ignore cached JSON
```

The default window is the 12 most recent complete calendar months available in the archive, which lags real time by about 5–7 days. Whole months are used so that monthly totals are not biased by partial months.

## Project structure

```
config.py            cities, endpoints, variables, valid ranges, thresholds, WMO codes
run_pipeline.py      end-to-end pipeline (CLI)
app.py               Streamlit dashboard
src/api_client.py    Open-Meteo requests with retries, raw JSON caching, live JSON → DataFrame
src/processing.py    JSON → Pandas, data quality assessment, cleaning, feature engineering, daily aggregation
src/analysis.py      KPIs, 10 univariate, 10 bivariate, 10 multivariate, 6 time-series, extremes, city comparison
src/report.py        writes outputs/report.md: insights, recommendations, limitations, conclusion
.streamlit/config.toml  dashboard theme
```

Generated at run time (git-ignored):

```
data/raw/*.json              untouched API responses, one per city (audit trail)
data/processed/hourly.parquet, daily.parquet, meta.json
outputs/report.md            the full written analysis
outputs/figures/*.png        ~38 charts referenced by the report
outputs/tables/*.csv         KPI, city comparison, alert thresholds and every analysis table
```

## How the brief's workflow maps to the code

| Stage | Where |
|---|---|
| API connection, historical and live extraction | `api_client.fetch_historical_all`, `api_client.fetch_live` |
| JSON → Pandas | `processing.payloads_to_frame`, `api_client.live_current_to_df` |
| Data exploration | pipeline logs dtypes, head and coverage; report section 1 |
| Data quality assessment | `processing.quality_assessment`: completeness, missingness, duplicates, timestamp gaps, out-of-range values, internal consistency (rain ≤ precipitation, dew point ≤ temperature, gust ≥ wind) |
| Cleaning | `processing.clean`: dedupe, enforce a full hourly grid, null implausible values, interpolate continuous gaps of 3 h or less, never invent rainfall, flag imputed rows |
| Feature engineering | `processing.add_features`, `processing.daily_aggregate`: DST-aware local time, season, condition groups, Beaufort force, bands, rolling 24 h/168 h and 7/30-day means, pressure tendency, temperature anomaly, extreme-day flags |
| 12 KPIs (covers the 10 required) | `analysis.compute_kpis` |
| 10 univariate analyses | `analysis.univariate` (U1–U10) |
| 10 bivariate analyses | `analysis.bivariate` (B1–B10) |
| 10 multivariate analyses | `analysis.multivariate` (M1–M10, incl. a correlation matrix and a standardised regression) |
| Time series | `analysis.time_series` (T1–T6: rolling means, weekly/monthly resampling, anomalies, autocorrelation, dry spells) |
| Extremes and city comparison | `analysis.extremes`, `analysis.city_comparison` |
| Dashboard | `app.py` |
| Insights, recommendations, limitations, conclusion | `report.py` → `outputs/report.md` sections 12–15 |

## Dashboard

- **Live panel** (auto-refreshes every 5–30 min, chosen in the sidebar): KPI cards for the focus city, each compared with that city's historical mean for the same month and hour. It also has threshold alerts (gale-force gusts, heavy rain rate, sub-zero temperature), a live UK temperature map, an all-city table, and a yesterday-to-tomorrow chart.
- **History controls:** focus city, cities to compare, date range.
- **Tabs:** temperature and rainfall trends (daily, 7-day and 30-day smoothing, hourly 24 h/168 h rolling); humidity and wind (density plot, rain chance by humidity, wind rose, pressure bands); city comparison (table, ranking bars, city × month heatmaps); seasonal and daily patterns; extremes with suggested per-city alert thresholds; data quality with a CSV download.

## Definitions (editable in `config.py`)

Rain hour ≥ 0.1 mm · heavy-rain hour ≥ 4 mm/h · wet day ≥ 1 mm · heavy-rain day ≥ 10 mm · frost day: minimum < 0 °C · summer day: maximum ≥ 25 °C · hot day: maximum ≥ 30 °C · gale-force gust ≥ 62 km/h · full day: at least 20 valid hours · seasons are meteorological (DJF, MAM, JJA, SON).

## Important caveats

Open-Meteo's historical data is ERA5-based reanalysis for the model grid cell nearest each city, not weather-station observations. Report section 14 lists the limitations this creates. Data is © Open-Meteo, licensed CC BY 4.0, free for non-commercial use (about 10,000 calls a day). Raw responses are cached, so re-running the analysis does not re-download.
